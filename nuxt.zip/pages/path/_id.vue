<template>
    <div>PATH: {{ $route.params.id }}</div>
</template>
