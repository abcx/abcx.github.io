<template>
        <div class="socialBar vertical visible" data-bd-viewability-id="socialbarVertical" data-bd-viewability="1">
            <ul class="sc_items">
                <li class="sc_item fbShare">
                    <a rel="nofollow" href="https://www.facebook.com/share.php?u=https%3a%2f%2fnext.gazeta.pl%2fnext%2f7%2c172690%2c27650905%2cnagroda-nobla-2021-akademia-oglosila-nazwiska-laureatow-w-dziedzinie.html#e=SbarLink">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="21.866" viewBox="0 0 22 21.866"><defs><style>.a_fb{fill:#fff;}</style></defs><path class="a_fb" d="M22,11A11,11,0,1,0,9.281,21.866V14.18H6.488V11H9.281V8.577c0-2.757,1.642-4.28,4.155-4.28a16.915,16.915,0,0,1,2.462.215V7.219H14.511a1.59,1.59,0,0,0-1.793,1.718V11H15.77l-.488,3.18H12.719v7.687A11,11,0,0,0,22,11Z"></path></svg>
                        </a>
                    <span class="count">&nbsp;</span>
                </li>
                <li class="sc_item comments">
                    <a rel="nofollow" href="#opinions">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><defs><style>.a_comm{fill:#fff;}</style></defs><path class="a_comm" d="M969,531H953a2,2,0,0,0-2,2v18l4-4h14a2,2,0,0,0,2-2V533A2,2,0,0,0,969,531Z" transform="translate(-951 -531)"></path></svg>
                    </a>
                    <span class="count active">66</span>
                </li>
                <li class="sc_item related_gallery_closing_button"><span>Zamknij galerię</span></li></ul>
        </div>
</template>


<script>
export default {
    props: ['test']
}
</script>