<template>
<div class="box_seo">
<ul class="content">
<li class="seo_column">
<h3>
Najpopularniejsze
</h3>
<ul>
<li class="seo_row">
<a href="https://next.gazeta.pl/komputery" title="Komputery">Komputery</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/fizyka" title="Fizyka">Fizyka</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/medycyna" title="Medycyna">Medycyna</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/roboty" title="Roboty">Roboty</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/sztuczna-inteligencja" title="Sztuczna inteligencja">Sztuczna inteligencja</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/smartfony" title="Smartfony">Smartfony</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/next/0,172392.html" title="Środowisko">Środowisko</a>
</li>
</ul>
</li>
<li class="seo_column">
<h3>
Multimedia
</h3>
<ul>
<li class="seo_row">
<a href="https://next.gazeta.pl/pc" title="PC">PC</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/playstation" title="PlayStation">PlayStation</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/xbox-one" title="xBox">xBox</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/ios" title="iOS">iOS</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/tesla" title="Tesla">Tesla</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/iphone" title="Iphone">Iphone</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/internet/0,0.html" title="Internet">Internet</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/netflix" title="Netflix">Netflix</a>
</li>
</ul>
</li>
<li class="seo_column">
<h3>
Polecamy
</h3>
<ul>
<li class="seo_row">
<a href="https://next.gazeta.pl/elon-musk" title="Elon Musk">Elon Musk</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/starlink" title="Starlink">Starlink</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/kredyt" title="Kredyt">Kredyt</a>
</li><li class="seo_row">
<a href="https://wiadomosci.gazeta.pl/wiadomosci/0,114916.html?tag=niedziele+handlowe+2018" title="Niedziele Handlowe">Niedziele Handlowe</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/zakaz-handlu-w-niedziele" title="Zakaz handlu w niedziele">Zakaz handlu w niedziele</a>
</li><li class="seo_row">
<a href="https://wiadomosci.gazeta.pl/wiadomosci/0,114916.html?tag=biedronka" title="Biedronka">Biedronka</a>
</li><li class="seo_row">
<a href="https://wiadomosci.gazeta.pl/wiadomosci/0,114916.html?tag=Lidl" title="Lidl">Lidl</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/next/0,173953.html" title="Koronawirus">Koronawirus</a>
</li>
</ul>
</li>
<li class="seo_column">
<h3>
Tematy
</h3>
<ul>
<li class="seo_row">
<a href="https://next.gazeta.pl/kursy-walut" title="Kursy walut">Kursy walut</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/kurs-funta" title="Kurs funta">Kurs funta</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/kurs-franka" title="Kurs franka">Kurs franka</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/kurs-euro" title="Kurs euro">Kurs euro</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/kurs-dolara" title="Kurs dolara">Kurs dolara</a>
</li><li class="seo_row">
<a href="https://wiadomosci.gazeta.pl/wiadomosci/0,114916.html?tag=auchan" title="Auchan">Auchan</a>
</li><li class="seo_row">
<a href="https://wiadomosci.gazeta.pl/wiadomosci/0,114916.html?tag=Tesco" title="Tesco">Tesco</a>
</li><li class="seo_row">
<a href="http://lab.gazeta.pl/" title="Quality Lab - Konferencja">Quality Lab - Konferencja</a>
</li>
</ul>
</li>
<li class="seo_column">
<h3>
<a href="https://zakupy.avanti24.pl/" title="Zakupy">Zakupy</a>
</h3>
<ul>
<li class="seo_row">
<a href="https://zakupy.avanti24.pl/koszule/meskie" title="Koszule męskie">Koszule męskie</a>
</li><li class="seo_row">
<a href="https://avanti24.pl/trendy-mody" title="Trendy mody">Trendy mody</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/kurtki/meskie" title="Kurtki męskie">Kurtki męskie</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/kalosze/meskie" title="Kalosze na jesień">Kalosze na jesień</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/kurtki/nike/meskie" title="Kurtki Nike">Kurtki Nike</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/jeansy/meskie" title="Modne jeansy">Modne jeansy</a>
</li><li class="seo_row">
<a href="https://avanti24.pl/hot" title="Hot trendy">Hot trendy</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/polbuty/meskie" title="Półbuty na jesień">Półbuty na jesień</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/bluzy/vans/meskie" title="Bluzy Vans">Bluzy Vans</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/sneakersy/meskie" title="Sneakersy na jesień">Sneakersy na jesień</a>
</li>
</ul>
</li>
<li class="seo_column">
<h3>
Dom
</h3>
<ul>
<li class="seo_row">
<a href="https://czterykaty.pl/inspiracje/7,153170,24386315,mop-obrotowy-czy-plaski-ktory-lepiej-wybrac.html" title="Mop obrotowy">Mop obrotowy</a>
</li><li class="seo_row">
<a href="https://czterykaty.pl/inspiracje/7,153170,24471411,frytkownica-beztluszczowa-jak-dziala-jaki-model-wybrac.html" title="Frytkownica beztłuszczowa">Frytkownica beztłuszczowa</a>
</li><li class="seo_row">
<a href="https://czterykaty.pl/inspiracje/7,153170,27184122,kwiaty-do-lazienki-ktore-rosliny-najlepiej-nadaja-sie-jako.html" title="Kwiaty do łazienki">Kwiaty do łazienki</a>
</li><li class="seo_row">
<a href="https://czterykaty.pl/czterykaty/1,57597,7524875,panele-laminowane-wady-i-zalety.html" title="Panele laminowane">Panele laminowane</a>
</li><li class="seo_row">
<a href="https://czterykaty.pl/inspiracje/7,153170,24984599,multicooker-wielofunkcyjne-urzadzenie-czy-warto-go-miec.html" title="Multicookery">Multicookery</a>
</li><li class="seo_row">
<a href="https://czterykaty.pl/inspiracje/7,153170,27187070,robot-kuchenny-planetarny-urzadzenie-ktore-jest-nieocenionym.html" title="Robot kuchenny planetarny">Robot kuchenny planetarny</a>
</li><li class="seo_row">
<a href="https://czterykaty.pl/inspiracje/7,153170,27203446,ogrodowe-ozdobne-lampy-solarne-te-modele-zachwycaja-szczegolnie.html" title="Lampy solarne ogrodowe">Lampy solarne ogrodowe</a>
</li><li class="seo_row">
<a href="https://czterykaty.pl/czterykaty/1,133333,13705037,ile-kosztuje-sufit-podwieszany-w-lazience-kuchni-nad-czescia.html" title="Sufit podwieszany">Sufit podwieszany</a>
</li>
</ul>
</li>
<li class="seo_column">
<h3>
<a href="https://next.gazeta.pl/internet/1,104530,9516971,redakcja-serwisu-next-gazeta-pl.html" title="Kontakt">Kontakt</a>
</h3>
<ul>
<li class="seo_row">
<a href="" title="ul. Czerska 8/10">ul. Czerska 8/10</a>
</li><li class="seo_row">
<a href="" title="00-732 Warszawa">00-732 Warszawa</a>
</li><li class="seo_row">
<a href="mailto:next.redakcja@agora.pl" title="Napisz do nas">Napisz do nas</a>
</li>
</ul>
</li>
</ul>
</div>
</template>


<script>
export default {
    props: ['test']
}
</script>