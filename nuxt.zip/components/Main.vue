<template>
    <div>
        <Header :test="asyncProp"/>
        <Article :data="apiSecret"/>
        <Aside/>
        <Bottom/>
        <BoxSeo/>
        <Footer/>
    </div>
</template>

<style>
#onn-player__player {display:none}
</style>

<script>
    import data from '../article.json';

    export default {
        layout (context) {
            return 'default'
        },
        data() {
            return {
                asyncProp: '',
                apiSecret: data
            }
        },
        head() {
            return {
                title: this.title,
                bodyAttrs: {
                    id: 'pageTypeId_7',
                    class: 'chrome WebKit chrome_9 LINUX simpleArt '
                }
            }
        },
        methods: {
            getAsyncData() {
                new Promise((resolve, reject) => {
                    setTimeout(_ => {
                        resolve('abcx');
                    }, 100);
                }).then((res) => {
                    this.asyncProp = res;
                });
            }
        },
        created() {
            this.getAsyncData();
        }
    }
</script>