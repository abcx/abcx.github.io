<template>
<div id="bottom_wrapper" class="section_wrapper">
    <div class="content_wrap">
        <!-- .comment_box: false / false -->
        <div class="columns_container withCommentsApp">
                    <div class="main_content">
                        <script type="application/json" id="commentsAppJson">
                            {
                                "showComments": "",
                                "commentsCounter": "30",
                                "commentsLoggedUsers": "tak",
                                "commentsVisibleLinks": "",
                                "commentsLoginPage": "https://konto.gazeta.pl/konto/logowanie,.html}",
                                "commentsRegisterPage": "https://konto.gazeta.pl/konto/szybka-rejestracja.do",
                                "commentsAllCommentsPage": "",
                                "commentsDateFrom": "",
                                "commentsSortingRule" : "",
                                "commentsScoringLoggedUsers": "nie"
                            }
                        </script>
                        <div id="opinions"></div>
                        <div id="commentsApp" class="commentsApp">

    <div class="commentsApp__header">
        <h3 class="commentsApp__heading">Komentarze <span class="commentsApp__headerCounter" id="commentsApp__headerCounter">(66)</span></h3>
        <div class="commentsApp__sorting">
            <button type="button" class="commentsApp__BoxTrigger commentsApp__textStyledBtn commentsApp__sortingSelected commentsApp__interactiveEl" data-action="openSortBox">od najpopularniejszych<svg class="commentsApp__sortingTriangle" xmlns="http://www.w3.org/2000/svg" width="8" height="4" viewBox="0 0 8 4"><g transform="translate(-162.667 -6.667)"><path class="commentsApp__sortingTrianglePath" d="M7,10l4,4,4-4Z" transform="translate(155.667 -3.333)"></path></g></svg></button>
            <div class="commentsApp__Box commentsApp__Box--sorting">
                <button type="button" class="commentsApp__BoxOption commentsApp__textStyledBtn  commentsApp__BoxOption--sorting commentsApp__interactiveEl" data-type="newest" data-action="sort" data-text="od najnowszych">Sortuj od najnowszych</button>
                <button type="button" class="commentsApp__BoxOption commentsApp__textStyledBtn  commentsApp__BoxOption--sorting commentsApp__interactiveEl" data-type="oldest" data-action="sort" data-text="od najstarszych">Sortuj od najstarszych</button>
                <button type="button" class="commentsApp__BoxOption commentsApp__textStyledBtn commentsApp__BoxOption--active commentsApp__BoxOption--sorting commentsApp__interactiveEl" data-type="popular" data-action="sort" data-text="od najpopularniejszych">Sortuj od najpopularniejszych</button>
            </div>
        </div>
    </div>
    <div class="commentsApp__articleTitle">
        <p>Nagroda Nobla 2021. Akademia ogłosiła nazwiska laureatów w dziedzinie fizyki. Klimat w tle</p>
    </div>


        <form class="commentsApp__textField">
            <textarea data-oxx="0" class="commentsApp__addCommentTextarea commentsApp__interactiveEl commentsApp__addCommentTextarea--revealBottom" placeholder="Dodaj komentarz..." data-action="revealBottom" rows="1"></textarea>
            <div class="commentsApp__bottom">
                <div class="commentsApp__bottomFrame commentsApp__interactiveEl" data-action="showChangeButton">
                    <div class="commentsApp__bottomFrameElement commentsApp__userName commentsApp__interactiveEl" data-action="showChangeButton"></div>
                    <button class="commentsApp__textStyledBtn commentsApp__change commentsApp__interactiveEl" data-action="popupChange" data-oxx="0">Zmień</button>
                </div>
                <div>
                    <button onmouseover="this.focus()" data-oxx="0" type="button" class="commentsApp__button commentsApp__button--login commentsApp__interactiveEl" data-action="popup">Zaloguj się i skomentuj</button>
                    <button onmouseover="this.focus()" data-oxx="0" type="button" class="commentsApp__button commentsApp__button--send commentsApp__interactiveEl" data-action="send">Skomentuj</button>
                </div>
            </div>
            <input type="hidden" name="OXX" value="0"><input type="hidden" name="logged" value="false">
        </form>
        <div class="commentsApp__infoMessage" data-message="0"><span class="commentsApp__infoMessageText"></span><span data-action="closeMessage" class="commentsApp__interactiveEl commentsApp__infoMessageClose">✖</span></div>


    <div class="commentsApp__commentsContainer">


        <div class="commentsApp__comment" id="commentId62795831" data-deleted="no" data-entryid="62795831" data-date="1633428762" data-votesrank="16" style="order:1">
            <div class="commentsApp__commentHead">
                <div class="commentsApp__commentAuthor">minister_wszystkiego</div>
                <div class="commentsApp__commentDate">3 godziny temu</div>
                <div class="commentsApp__commentLink commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795831"><div class="commentsApp__commentLinkInfo">URL komentarza skopiowany do schowka</div><button class="commentsApp__commentLinkButton commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795831"><svg class="commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795831" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"><defs><style>.a{fill:#666;opacity:0.87;}</style></defs><path class="a commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795831" d="M8.69,10.825a.737.737,0,0,1,0,1.075.763.763,0,0,1-1.075,0,3.789,3.789,0,0,1,0-5.355h0L10.3,3.865A3.786,3.786,0,0,1,15.65,9.22l-1.128,1.128a5.232,5.232,0,0,0-.3-1.833l.356-.364a2.271,2.271,0,0,0-3.211-3.211L8.69,7.614a2.258,2.258,0,0,0,0,3.211m2.136-3.211a.763.763,0,0,1,1.075,0,3.789,3.789,0,0,1,0,5.355h0L9.22,15.65A3.786,3.786,0,0,1,3.865,10.3L4.994,9.167a5.3,5.3,0,0,0,.3,1.84l-.356.356a2.271,2.271,0,0,0,3.211,3.211L10.825,11.9a2.258,2.258,0,0,0,0-3.211A.737.737,0,0,1,10.825,7.614Z" transform="translate(-2.758 -2.758)"></path></svg></button></div>
                <div class="commentsApp__options">
                    <button type="button" class="commentsApp__BoxTrigger commentsApp__textStyledBtn commentsApp__optionsDots commentsApp__interactiveEl" data-action="optionsBox"></button>
                    <div class="commentsApp__Box commentsApp__Box--options">
                        <button type="button" class="commentsApp__BoxOption commentsApp__textStyledBtn commentsApp__BoxOption--report commentsApp__interactiveEl" data-action="report">Zgłoś komentarz</button>
                    </div>
                </div>
            </div>
            <div class="commentsApp__commentBody">Powinien dostać ojciec dyrektor za odkrycie jak falami radiowymi sterować czarną masą. Albo Czarnek za odkrycie, że bibliologia jest nauką</div>
            <div class="commentsApp__commentFooter">
                <div class="commentsApp__votes">
                    <div class="commentsApp__votesInfo">Aby ocenić <a href="#" class="commentsApp__interactiveEl" data-action="popupVote" data-oxx="62795831">zaloguj się</a> lub <a href="https://konto.gazeta.pl/konto/rejestracja,.html?back=https://next.gazeta.pl/next/7,172690,27650905,nagroda-nobla-2021-akademia-oglosila-nazwiska-laureatow-w-dziedzinie.html">zarejestruj</a> <span class="commentsApp__votesInfo--close commentsApp__interactiveEl" data-action="votesInfoClose">✖</span></div>
                    <button id="voteUpLogged62795831" type="button" class="commentsApp__vote commentsApp__vote--up commentsApp__vote--logged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="voteUp"><svg class="commentsApp__voteSVG commentsApp__vodeSVG--up commentsApp__interactiveEl" data-action="voteUp" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="voteUp" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="voteUp" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M1,14.333H3.667v-8H1ZM15.667,7a1.337,1.337,0,0,0-1.333-1.333H10.127L10.76,2.62l.02-.213a1,1,0,0,0-.293-.707L9.78,1,5.393,5.393A1.3,1.3,0,0,0,5,6.333V13a1.337,1.337,0,0,0,1.333,1.333h6a1.324,1.324,0,0,0,1.227-.813l2.013-4.7a1.317,1.317,0,0,0,.093-.487Z" transform="translate(-0.333 -0.333)"></path></svg> <span id="plusVoteA_62795831">25</span></button>
                    <button id="voteDownLogged62795831" type="button" class="commentsApp__vote commentsApp__vote--down commentsApp__vote--logged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="voteDown"><svg class="commentsApp__voteSVG commentsApp__vodeSVG--down commentsApp__interactiveEl" data-action="voteDown" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="voteDown" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="voteDown" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M10.333,3h-6a1.324,1.324,0,0,0-1.227.813l-2.013,4.7A1.317,1.317,0,0,0,1,9v1.333a1.337,1.337,0,0,0,1.333,1.333H6.54l-.633,3.047-.02.213a1,1,0,0,0,.293.707l.707.7L11.28,11.94a1.325,1.325,0,0,0,.387-.94V4.333A1.337,1.337,0,0,0,10.333,3ZM13,3v8h2.667V3Z" transform="translate(-0.333 -1)"></path></svg> <span id="minusVoteA_62795831">9</span></button>
                    <button id="voteUpLoggedOut62795831" title="Aby ocenić zaloguj się lub zarejestruj" type="button" class="commentsApp__vote commentsApp__vote--up commentsApp__vote--unlogged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="votesInfo"><svg data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVG commentsApp__vodeSVG--up" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M1,14.333H3.667v-8H1ZM15.667,7a1.337,1.337,0,0,0-1.333-1.333H10.127L10.76,2.62l.02-.213a1,1,0,0,0-.293-.707L9.78,1,5.393,5.393A1.3,1.3,0,0,0,5,6.333V13a1.337,1.337,0,0,0,1.333,1.333h6a1.324,1.324,0,0,0,1.227-.813l2.013-4.7a1.317,1.317,0,0,0,.093-.487Z" transform="translate(-0.333 -0.333)"></path></svg> <span id="plusVoteB_62795831">25</span></button>
                    <button id="voteDownLoggedOut62795831" title="Aby ocenić zaloguj się lub zarejestruj" type="button" class="commentsApp__vote commentsApp__vote--down commentsApp__vote--unlogged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="votesInfo"><svg data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVG commentsApp__vodeSVG--down" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M10.333,3h-6a1.324,1.324,0,0,0-1.227.813l-2.013,4.7A1.317,1.317,0,0,0,1,9v1.333a1.337,1.337,0,0,0,1.333,1.333H6.54l-.633,3.047-.02.213a1,1,0,0,0,.293.707l.707.7L11.28,11.94a1.325,1.325,0,0,0,.387-.94V4.333A1.337,1.337,0,0,0,10.333,3ZM13,3v8h2.667V3Z" transform="translate(-0.333 -1)"></path></svg> <span id="minusVoteB_62795831">9</span></button>
                </div>
                <button type="button" class="commentsApp__reply commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="reply">Odpowiedz</button>

                <button type="button" class="commentsApp__showReplies commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="showReplies"><span class="commentsApp__showRepliesText commentsApp__interactiveEl" data-action="showReplies">Pokaż odpowiedzi</span> (4)</button>

            </div>

        <form class="commentsApp__textField">
            <textarea data-oxx="62795831" class="commentsApp__addCommentTextarea commentsApp__interactiveEl commentsApp__addCommentTextarea--revealBottom" placeholder="Dodaj komentarz..." data-action="revealBottom" rows="1"></textarea>
            <div class="commentsApp__bottom">
                <div class="commentsApp__bottomFrame commentsApp__interactiveEl" data-action="showChangeButton">
                    <div class="commentsApp__bottomFrameElement commentsApp__userName commentsApp__interactiveEl" data-action="showChangeButton"></div>
                    <button class="commentsApp__textStyledBtn commentsApp__change commentsApp__interactiveEl" data-action="popupChange" data-oxx="62795831">Zmień</button>
                </div>
                <div>
                    <button onmouseover="this.focus()" data-oxx="62795831" type="button" class="commentsApp__button commentsApp__button--login commentsApp__interactiveEl" data-action="popup">Zaloguj się i skomentuj</button>
                    <button onmouseover="this.focus()" data-oxx="62795831" type="button" class="commentsApp__button commentsApp__button--send commentsApp__interactiveEl" data-action="send">Skomentuj</button>
                </div>
            </div>
            <input type="hidden" name="OXX" value="62795831">
        </form>
        <div class="commentsApp__infoMessage" data-message="62795831"><span class="commentsApp__infoMessageText"></span><span data-action="closeMessage" class="commentsApp__interactiveEl commentsApp__infoMessageClose">✖</span></div>

            <div class="commentsApp__subComments"></div>
        </div>

        <div class="commentsApp__comment commentsApp__comment--adsInserted" id="commentId62795973" data-deleted="no" data-entryid="62795973" data-date="1633429303" data-votesrank="14" style="order:2">
            <div class="commentsApp__commentHead">
                <div class="commentsApp__commentAuthor">strach_sie_bac</div>
                <div class="commentsApp__commentDate">3 godziny temu</div>
                <div class="commentsApp__commentLink commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795973"><div class="commentsApp__commentLinkInfo">URL komentarza skopiowany do schowka</div><button class="commentsApp__commentLinkButton commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795973"><svg class="commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795973" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"><defs><style>.a{fill:#666;opacity:0.87;}</style></defs><path class="a commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795973" d="M8.69,10.825a.737.737,0,0,1,0,1.075.763.763,0,0,1-1.075,0,3.789,3.789,0,0,1,0-5.355h0L10.3,3.865A3.786,3.786,0,0,1,15.65,9.22l-1.128,1.128a5.232,5.232,0,0,0-.3-1.833l.356-.364a2.271,2.271,0,0,0-3.211-3.211L8.69,7.614a2.258,2.258,0,0,0,0,3.211m2.136-3.211a.763.763,0,0,1,1.075,0,3.789,3.789,0,0,1,0,5.355h0L9.22,15.65A3.786,3.786,0,0,1,3.865,10.3L4.994,9.167a5.3,5.3,0,0,0,.3,1.84l-.356.356a2.271,2.271,0,0,0,3.211,3.211L10.825,11.9a2.258,2.258,0,0,0,0-3.211A.737.737,0,0,1,10.825,7.614Z" transform="translate(-2.758 -2.758)"></path></svg></button></div>
                <div class="commentsApp__options">
                    <button type="button" class="commentsApp__BoxTrigger commentsApp__textStyledBtn commentsApp__optionsDots commentsApp__interactiveEl" data-action="optionsBox"></button>
                    <div class="commentsApp__Box commentsApp__Box--options">
                        <button type="button" class="commentsApp__BoxOption commentsApp__textStyledBtn commentsApp__BoxOption--report commentsApp__interactiveEl" data-action="report">Zgłoś komentarz</button>
                    </div>
                </div>
            </div>
            <div class="commentsApp__commentBody">- Słyszeliście, że ojciec Rydzyk został nominowany do nagrody Nobla z fizyki?<br>
- Za co?<br>
- Za przyciąganie ciemnej masy falami radiowymi.</div>
            <div class="commentsApp__commentFooter">
                <div class="commentsApp__votes">
                    <div class="commentsApp__votesInfo">Aby ocenić <a href="#" class="commentsApp__interactiveEl" data-action="popupVote" data-oxx="62795973">zaloguj się</a> lub <a href="https://konto.gazeta.pl/konto/rejestracja,.html?back=https://next.gazeta.pl/next/7,172690,27650905,nagroda-nobla-2021-akademia-oglosila-nazwiska-laureatow-w-dziedzinie.html">zarejestruj</a> <span class="commentsApp__votesInfo--close commentsApp__interactiveEl" data-action="votesInfoClose">✖</span></div>
                    <button id="voteUpLogged62795973" type="button" class="commentsApp__vote commentsApp__vote--up commentsApp__vote--logged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="voteUp"><svg class="commentsApp__voteSVG commentsApp__vodeSVG--up commentsApp__interactiveEl" data-action="voteUp" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="voteUp" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="voteUp" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M1,14.333H3.667v-8H1ZM15.667,7a1.337,1.337,0,0,0-1.333-1.333H10.127L10.76,2.62l.02-.213a1,1,0,0,0-.293-.707L9.78,1,5.393,5.393A1.3,1.3,0,0,0,5,6.333V13a1.337,1.337,0,0,0,1.333,1.333h6a1.324,1.324,0,0,0,1.227-.813l2.013-4.7a1.317,1.317,0,0,0,.093-.487Z" transform="translate(-0.333 -0.333)"></path></svg> <span id="plusVoteA_62795973">18</span></button>
                    <button id="voteDownLogged62795973" type="button" class="commentsApp__vote commentsApp__vote--down commentsApp__vote--logged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="voteDown"><svg class="commentsApp__voteSVG commentsApp__vodeSVG--down commentsApp__interactiveEl" data-action="voteDown" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="voteDown" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="voteDown" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M10.333,3h-6a1.324,1.324,0,0,0-1.227.813l-2.013,4.7A1.317,1.317,0,0,0,1,9v1.333a1.337,1.337,0,0,0,1.333,1.333H6.54l-.633,3.047-.02.213a1,1,0,0,0,.293.707l.707.7L11.28,11.94a1.325,1.325,0,0,0,.387-.94V4.333A1.337,1.337,0,0,0,10.333,3ZM13,3v8h2.667V3Z" transform="translate(-0.333 -1)"></path></svg> <span id="minusVoteA_62795973">4</span></button>
                    <button id="voteUpLoggedOut62795973" title="Aby ocenić zaloguj się lub zarejestruj" type="button" class="commentsApp__vote commentsApp__vote--up commentsApp__vote--unlogged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="votesInfo"><svg data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVG commentsApp__vodeSVG--up" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M1,14.333H3.667v-8H1ZM15.667,7a1.337,1.337,0,0,0-1.333-1.333H10.127L10.76,2.62l.02-.213a1,1,0,0,0-.293-.707L9.78,1,5.393,5.393A1.3,1.3,0,0,0,5,6.333V13a1.337,1.337,0,0,0,1.333,1.333h6a1.324,1.324,0,0,0,1.227-.813l2.013-4.7a1.317,1.317,0,0,0,.093-.487Z" transform="translate(-0.333 -0.333)"></path></svg> <span id="plusVoteB_62795973">18</span></button>
                    <button id="voteDownLoggedOut62795973" title="Aby ocenić zaloguj się lub zarejestruj" type="button" class="commentsApp__vote commentsApp__vote--down commentsApp__vote--unlogged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="votesInfo"><svg data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVG commentsApp__vodeSVG--down" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M10.333,3h-6a1.324,1.324,0,0,0-1.227.813l-2.013,4.7A1.317,1.317,0,0,0,1,9v1.333a1.337,1.337,0,0,0,1.333,1.333H6.54l-.633,3.047-.02.213a1,1,0,0,0,.293.707l.707.7L11.28,11.94a1.325,1.325,0,0,0,.387-.94V4.333A1.337,1.337,0,0,0,10.333,3ZM13,3v8h2.667V3Z" transform="translate(-0.333 -1)"></path></svg> <span id="minusVoteB_62795973">4</span></button>
                </div>
                <button type="button" class="commentsApp__reply commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="reply">Odpowiedz</button>

            </div>

        <form class="commentsApp__textField">
            <textarea data-oxx="62795973" class="commentsApp__addCommentTextarea commentsApp__interactiveEl commentsApp__addCommentTextarea--revealBottom" placeholder="Dodaj komentarz..." data-action="revealBottom" rows="1"></textarea>
            <div class="commentsApp__bottom">
                <div class="commentsApp__bottomFrame commentsApp__interactiveEl" data-action="showChangeButton">
                    <div class="commentsApp__bottomFrameElement commentsApp__userName commentsApp__interactiveEl" data-action="showChangeButton"></div>
                    <button class="commentsApp__textStyledBtn commentsApp__change commentsApp__interactiveEl" data-action="popupChange" data-oxx="62795973">Zmień</button>
                </div>
                <div>
                    <button onmouseover="this.focus()" data-oxx="62795973" type="button" class="commentsApp__button commentsApp__button--login commentsApp__interactiveEl" data-action="popup">Zaloguj się i skomentuj</button>
                    <button onmouseover="this.focus()" data-oxx="62795973" type="button" class="commentsApp__button commentsApp__button--send commentsApp__interactiveEl" data-action="send">Skomentuj</button>
                </div>
            </div>
            <input type="hidden" name="OXX" value="62795973">
        </form>
        <div class="commentsApp__infoMessage" data-message="62795973"><span class="commentsApp__infoMessageText"></span><span data-action="closeMessage" class="commentsApp__interactiveEl commentsApp__infoMessageClose">✖</span></div>


        <div id="DFP-011-MIDBOARD_62795973" data-google-query-id="CK2Sjbmzs_MCFZexsgod7msO8w" class="activeBan adviewDFPBanner" style="margin-left: auto; margin-right: auto; min-width: 750px; max-width: 750px;"><span class="banLabel" style="display: block; max-width: 750px; margin-left: auto; margin-right: auto;">REKLAMA</span><div id="google_ads_iframe_/75224259/AGORA-IN/Next/011-MIDBOARD_2__container__" style="border: 0pt none; display: inline-block; width: 750px; height: 300px;"><iframe frameborder="0" src="https://945d610509ca599ab5d9a913eec7b95a.safeframe.googlesyndication.com/safeframe/1-0-38/html/container.html" id="google_ads_iframe_/75224259/AGORA-IN/Next/011-MIDBOARD_2" title="3rd party ad content" name="" scrolling="no" marginwidth="0" marginheight="0" width="750" height="300" data-is-safeframe="true" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" data-google-container-id="e" style="border: 0px; vertical-align: bottom;" data-load-complete="true"></iframe></div></div></div>

        <div class="commentsApp__comment" id="commentId62795902" data-deleted="no" data-entryid="62795902" data-date="1633428992" data-votesrank="9" style="order:3">
            <div class="commentsApp__commentHead">
                <div class="commentsApp__commentAuthor">pacior4</div>
                <div class="commentsApp__commentDate">3 godziny temu</div>
                <div class="commentsApp__commentLink commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795902"><div class="commentsApp__commentLinkInfo">URL komentarza skopiowany do schowka</div><button class="commentsApp__commentLinkButton commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795902"><svg class="commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795902" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"><defs><style>.a{fill:#666;opacity:0.87;}</style></defs><path class="a commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795902" d="M8.69,10.825a.737.737,0,0,1,0,1.075.763.763,0,0,1-1.075,0,3.789,3.789,0,0,1,0-5.355h0L10.3,3.865A3.786,3.786,0,0,1,15.65,9.22l-1.128,1.128a5.232,5.232,0,0,0-.3-1.833l.356-.364a2.271,2.271,0,0,0-3.211-3.211L8.69,7.614a2.258,2.258,0,0,0,0,3.211m2.136-3.211a.763.763,0,0,1,1.075,0,3.789,3.789,0,0,1,0,5.355h0L9.22,15.65A3.786,3.786,0,0,1,3.865,10.3L4.994,9.167a5.3,5.3,0,0,0,.3,1.84l-.356.356a2.271,2.271,0,0,0,3.211,3.211L10.825,11.9a2.258,2.258,0,0,0,0-3.211A.737.737,0,0,1,10.825,7.614Z" transform="translate(-2.758 -2.758)"></path></svg></button></div>
                <div class="commentsApp__options">
                    <button type="button" class="commentsApp__BoxTrigger commentsApp__textStyledBtn commentsApp__optionsDots commentsApp__interactiveEl" data-action="optionsBox"></button>
                    <div class="commentsApp__Box commentsApp__Box--options">
                        <button type="button" class="commentsApp__BoxOption commentsApp__textStyledBtn commentsApp__BoxOption--report commentsApp__interactiveEl" data-action="report">Zgłoś komentarz</button>
                    </div>
                </div>
            </div>
            <div class="commentsApp__commentBody">1. jeszcze troche i będa dzielić po 1/16<br>
2. poza tym biblistyka się liczy a nie jakas fizyka, spytajcie Czarnka</div>
            <div class="commentsApp__commentFooter">
                <div class="commentsApp__votes">
                    <div class="commentsApp__votesInfo">Aby ocenić <a href="#" class="commentsApp__interactiveEl" data-action="popupVote" data-oxx="62795902">zaloguj się</a> lub <a href="https://konto.gazeta.pl/konto/rejestracja,.html?back=https://next.gazeta.pl/next/7,172690,27650905,nagroda-nobla-2021-akademia-oglosila-nazwiska-laureatow-w-dziedzinie.html">zarejestruj</a> <span class="commentsApp__votesInfo--close commentsApp__interactiveEl" data-action="votesInfoClose">✖</span></div>
                    <button id="voteUpLogged62795902" type="button" class="commentsApp__vote commentsApp__vote--up commentsApp__vote--logged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="voteUp"><svg class="commentsApp__voteSVG commentsApp__vodeSVG--up commentsApp__interactiveEl" data-action="voteUp" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="voteUp" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="voteUp" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M1,14.333H3.667v-8H1ZM15.667,7a1.337,1.337,0,0,0-1.333-1.333H10.127L10.76,2.62l.02-.213a1,1,0,0,0-.293-.707L9.78,1,5.393,5.393A1.3,1.3,0,0,0,5,6.333V13a1.337,1.337,0,0,0,1.333,1.333h6a1.324,1.324,0,0,0,1.227-.813l2.013-4.7a1.317,1.317,0,0,0,.093-.487Z" transform="translate(-0.333 -0.333)"></path></svg> <span id="plusVoteA_62795902">10</span></button>
                    <button id="voteDownLogged62795902" type="button" class="commentsApp__vote commentsApp__vote--down commentsApp__vote--logged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="voteDown"><svg class="commentsApp__voteSVG commentsApp__vodeSVG--down commentsApp__interactiveEl" data-action="voteDown" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="voteDown" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="voteDown" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M10.333,3h-6a1.324,1.324,0,0,0-1.227.813l-2.013,4.7A1.317,1.317,0,0,0,1,9v1.333a1.337,1.337,0,0,0,1.333,1.333H6.54l-.633,3.047-.02.213a1,1,0,0,0,.293.707l.707.7L11.28,11.94a1.325,1.325,0,0,0,.387-.94V4.333A1.337,1.337,0,0,0,10.333,3ZM13,3v8h2.667V3Z" transform="translate(-0.333 -1)"></path></svg> <span id="minusVoteA_62795902">1</span></button>
                    <button id="voteUpLoggedOut62795902" title="Aby ocenić zaloguj się lub zarejestruj" type="button" class="commentsApp__vote commentsApp__vote--up commentsApp__vote--unlogged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="votesInfo"><svg data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVG commentsApp__vodeSVG--up" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M1,14.333H3.667v-8H1ZM15.667,7a1.337,1.337,0,0,0-1.333-1.333H10.127L10.76,2.62l.02-.213a1,1,0,0,0-.293-.707L9.78,1,5.393,5.393A1.3,1.3,0,0,0,5,6.333V13a1.337,1.337,0,0,0,1.333,1.333h6a1.324,1.324,0,0,0,1.227-.813l2.013-4.7a1.317,1.317,0,0,0,.093-.487Z" transform="translate(-0.333 -0.333)"></path></svg> <span id="plusVoteB_62795902">10</span></button>
                    <button id="voteDownLoggedOut62795902" title="Aby ocenić zaloguj się lub zarejestruj" type="button" class="commentsApp__vote commentsApp__vote--down commentsApp__vote--unlogged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="votesInfo"><svg data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVG commentsApp__vodeSVG--down" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M10.333,3h-6a1.324,1.324,0,0,0-1.227.813l-2.013,4.7A1.317,1.317,0,0,0,1,9v1.333a1.337,1.337,0,0,0,1.333,1.333H6.54l-.633,3.047-.02.213a1,1,0,0,0,.293.707l.707.7L11.28,11.94a1.325,1.325,0,0,0,.387-.94V4.333A1.337,1.337,0,0,0,10.333,3ZM13,3v8h2.667V3Z" transform="translate(-0.333 -1)"></path></svg> <span id="minusVoteB_62795902">1</span></button>
                </div>
                <button type="button" class="commentsApp__reply commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="reply">Odpowiedz</button>

            </div>

        <form class="commentsApp__textField">
            <textarea data-oxx="62795902" class="commentsApp__addCommentTextarea commentsApp__interactiveEl commentsApp__addCommentTextarea--revealBottom" placeholder="Dodaj komentarz..." data-action="revealBottom" rows="1"></textarea>
            <div class="commentsApp__bottom">
                <div class="commentsApp__bottomFrame commentsApp__interactiveEl" data-action="showChangeButton">
                    <div class="commentsApp__bottomFrameElement commentsApp__userName commentsApp__interactiveEl" data-action="showChangeButton"></div>
                    <button class="commentsApp__textStyledBtn commentsApp__change commentsApp__interactiveEl" data-action="popupChange" data-oxx="62795902">Zmień</button>
                </div>
                <div>
                    <button onmouseover="this.focus()" data-oxx="62795902" type="button" class="commentsApp__button commentsApp__button--login commentsApp__interactiveEl" data-action="popup">Zaloguj się i skomentuj</button>
                    <button onmouseover="this.focus()" data-oxx="62795902" type="button" class="commentsApp__button commentsApp__button--send commentsApp__interactiveEl" data-action="send">Skomentuj</button>
                </div>
            </div>
            <input type="hidden" name="OXX" value="62795902">
        </form>
        <div class="commentsApp__infoMessage" data-message="62795902"><span class="commentsApp__infoMessageText"></span><span data-action="closeMessage" class="commentsApp__interactiveEl commentsApp__infoMessageClose">✖</span></div>


        </div>

        <div class="commentsApp__comment" id="commentId62795909" data-deleted="no" data-entryid="62795909" data-date="1633429034" data-votesrank="9" style="order:4">
            <div class="commentsApp__commentHead">
                <div class="commentsApp__commentAuthor">gronostaj8</div>
                <div class="commentsApp__commentDate">3 godziny temu</div>
                <div class="commentsApp__commentLink commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795909"><div class="commentsApp__commentLinkInfo">URL komentarza skopiowany do schowka</div><button class="commentsApp__commentLinkButton commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795909"><svg class="commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795909" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"><defs><style>.a{fill:#666;opacity:0.87;}</style></defs><path class="a commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795909" d="M8.69,10.825a.737.737,0,0,1,0,1.075.763.763,0,0,1-1.075,0,3.789,3.789,0,0,1,0-5.355h0L10.3,3.865A3.786,3.786,0,0,1,15.65,9.22l-1.128,1.128a5.232,5.232,0,0,0-.3-1.833l.356-.364a2.271,2.271,0,0,0-3.211-3.211L8.69,7.614a2.258,2.258,0,0,0,0,3.211m2.136-3.211a.763.763,0,0,1,1.075,0,3.789,3.789,0,0,1,0,5.355h0L9.22,15.65A3.786,3.786,0,0,1,3.865,10.3L4.994,9.167a5.3,5.3,0,0,0,.3,1.84l-.356.356a2.271,2.271,0,0,0,3.211,3.211L10.825,11.9a2.258,2.258,0,0,0,0-3.211A.737.737,0,0,1,10.825,7.614Z" transform="translate(-2.758 -2.758)"></path></svg></button></div>
                <div class="commentsApp__options">
                    <button type="button" class="commentsApp__BoxTrigger commentsApp__textStyledBtn commentsApp__optionsDots commentsApp__interactiveEl" data-action="optionsBox"></button>
                    <div class="commentsApp__Box commentsApp__Box--options">
                        <button type="button" class="commentsApp__BoxOption commentsApp__textStyledBtn commentsApp__BoxOption--report commentsApp__interactiveEl" data-action="report">Zgłoś komentarz</button>
                    </div>
                </div>
            </div>
            <div class="commentsApp__commentBody">I znowu żadnego Polaka. Mamy KUL, mamy uczelnię ojca dyrektora i nic?</div>
            <div class="commentsApp__commentFooter">
                <div class="commentsApp__votes">
                    <div class="commentsApp__votesInfo">Aby ocenić <a href="#" class="commentsApp__interactiveEl" data-action="popupVote" data-oxx="62795909">zaloguj się</a> lub <a href="https://konto.gazeta.pl/konto/rejestracja,.html?back=https://next.gazeta.pl/next/7,172690,27650905,nagroda-nobla-2021-akademia-oglosila-nazwiska-laureatow-w-dziedzinie.html">zarejestruj</a> <span class="commentsApp__votesInfo--close commentsApp__interactiveEl" data-action="votesInfoClose">✖</span></div>
                    <button id="voteUpLogged62795909" type="button" class="commentsApp__vote commentsApp__vote--up commentsApp__vote--logged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="voteUp"><svg class="commentsApp__voteSVG commentsApp__vodeSVG--up commentsApp__interactiveEl" data-action="voteUp" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="voteUp" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="voteUp" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M1,14.333H3.667v-8H1ZM15.667,7a1.337,1.337,0,0,0-1.333-1.333H10.127L10.76,2.62l.02-.213a1,1,0,0,0-.293-.707L9.78,1,5.393,5.393A1.3,1.3,0,0,0,5,6.333V13a1.337,1.337,0,0,0,1.333,1.333h6a1.324,1.324,0,0,0,1.227-.813l2.013-4.7a1.317,1.317,0,0,0,.093-.487Z" transform="translate(-0.333 -0.333)"></path></svg> <span id="plusVoteA_62795909">11</span></button>
                    <button id="voteDownLogged62795909" type="button" class="commentsApp__vote commentsApp__vote--down commentsApp__vote--logged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="voteDown"><svg class="commentsApp__voteSVG commentsApp__vodeSVG--down commentsApp__interactiveEl" data-action="voteDown" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="voteDown" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="voteDown" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M10.333,3h-6a1.324,1.324,0,0,0-1.227.813l-2.013,4.7A1.317,1.317,0,0,0,1,9v1.333a1.337,1.337,0,0,0,1.333,1.333H6.54l-.633,3.047-.02.213a1,1,0,0,0,.293.707l.707.7L11.28,11.94a1.325,1.325,0,0,0,.387-.94V4.333A1.337,1.337,0,0,0,10.333,3ZM13,3v8h2.667V3Z" transform="translate(-0.333 -1)"></path></svg> <span id="minusVoteA_62795909">2</span></button>
                    <button id="voteUpLoggedOut62795909" title="Aby ocenić zaloguj się lub zarejestruj" type="button" class="commentsApp__vote commentsApp__vote--up commentsApp__vote--unlogged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="votesInfo"><svg data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVG commentsApp__vodeSVG--up" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M1,14.333H3.667v-8H1ZM15.667,7a1.337,1.337,0,0,0-1.333-1.333H10.127L10.76,2.62l.02-.213a1,1,0,0,0-.293-.707L9.78,1,5.393,5.393A1.3,1.3,0,0,0,5,6.333V13a1.337,1.337,0,0,0,1.333,1.333h6a1.324,1.324,0,0,0,1.227-.813l2.013-4.7a1.317,1.317,0,0,0,.093-.487Z" transform="translate(-0.333 -0.333)"></path></svg> <span id="plusVoteB_62795909">11</span></button>
                    <button id="voteDownLoggedOut62795909" title="Aby ocenić zaloguj się lub zarejestruj" type="button" class="commentsApp__vote commentsApp__vote--down commentsApp__vote--unlogged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="votesInfo"><svg data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVG commentsApp__vodeSVG--down" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M10.333,3h-6a1.324,1.324,0,0,0-1.227.813l-2.013,4.7A1.317,1.317,0,0,0,1,9v1.333a1.337,1.337,0,0,0,1.333,1.333H6.54l-.633,3.047-.02.213a1,1,0,0,0,.293.707l.707.7L11.28,11.94a1.325,1.325,0,0,0,.387-.94V4.333A1.337,1.337,0,0,0,10.333,3ZM13,3v8h2.667V3Z" transform="translate(-0.333 -1)"></path></svg> <span id="minusVoteB_62795909">2</span></button>
                </div>
                <button type="button" class="commentsApp__reply commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="reply">Odpowiedz</button>

                <button type="button" class="commentsApp__showReplies commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="showReplies"><span class="commentsApp__showRepliesText commentsApp__interactiveEl" data-action="showReplies">Pokaż odpowiedzi</span> (3)</button>

            </div>

        <form class="commentsApp__textField">
            <textarea data-oxx="62795909" class="commentsApp__addCommentTextarea commentsApp__interactiveEl commentsApp__addCommentTextarea--revealBottom" placeholder="Dodaj komentarz..." data-action="revealBottom" rows="1"></textarea>
            <div class="commentsApp__bottom">
                <div class="commentsApp__bottomFrame commentsApp__interactiveEl" data-action="showChangeButton">
                    <div class="commentsApp__bottomFrameElement commentsApp__userName commentsApp__interactiveEl" data-action="showChangeButton"></div>
                    <button class="commentsApp__textStyledBtn commentsApp__change commentsApp__interactiveEl" data-action="popupChange" data-oxx="62795909">Zmień</button>
                </div>
                <div>
                    <button onmouseover="this.focus()" data-oxx="62795909" type="button" class="commentsApp__button commentsApp__button--login commentsApp__interactiveEl" data-action="popup">Zaloguj się i skomentuj</button>
                    <button onmouseover="this.focus()" data-oxx="62795909" type="button" class="commentsApp__button commentsApp__button--send commentsApp__interactiveEl" data-action="send">Skomentuj</button>
                </div>
            </div>
            <input type="hidden" name="OXX" value="62795909">
        </form>
        <div class="commentsApp__infoMessage" data-message="62795909"><span class="commentsApp__infoMessageText"></span><span data-action="closeMessage" class="commentsApp__interactiveEl commentsApp__infoMessageClose">✖</span></div>

            <div class="commentsApp__subComments"></div>
        </div>

        <div class="commentsApp__comment" id="commentId62795864" data-deleted="no" data-entryid="62795864" data-date="1633428871" data-votesrank="8" style="order:5">
            <div class="commentsApp__commentHead">
                <div class="commentsApp__commentAuthor">cham-polski</div>
                <div class="commentsApp__commentDate">3 godziny temu</div>
                <div class="commentsApp__commentLink commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795864"><div class="commentsApp__commentLinkInfo">URL komentarza skopiowany do schowka</div><button class="commentsApp__commentLinkButton commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795864"><svg class="commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795864" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"><defs><style>.a{fill:#666;opacity:0.87;}</style></defs><path class="a commentsApp__interactiveEl" data-action="copyLink" data-id="commentId62795864" d="M8.69,10.825a.737.737,0,0,1,0,1.075.763.763,0,0,1-1.075,0,3.789,3.789,0,0,1,0-5.355h0L10.3,3.865A3.786,3.786,0,0,1,15.65,9.22l-1.128,1.128a5.232,5.232,0,0,0-.3-1.833l.356-.364a2.271,2.271,0,0,0-3.211-3.211L8.69,7.614a2.258,2.258,0,0,0,0,3.211m2.136-3.211a.763.763,0,0,1,1.075,0,3.789,3.789,0,0,1,0,5.355h0L9.22,15.65A3.786,3.786,0,0,1,3.865,10.3L4.994,9.167a5.3,5.3,0,0,0,.3,1.84l-.356.356a2.271,2.271,0,0,0,3.211,3.211L10.825,11.9a2.258,2.258,0,0,0,0-3.211A.737.737,0,0,1,10.825,7.614Z" transform="translate(-2.758 -2.758)"></path></svg></button></div>
                <div class="commentsApp__options">
                    <button type="button" class="commentsApp__BoxTrigger commentsApp__textStyledBtn commentsApp__optionsDots commentsApp__interactiveEl" data-action="optionsBox"></button>
                    <div class="commentsApp__Box commentsApp__Box--options">
                        <button type="button" class="commentsApp__BoxOption commentsApp__textStyledBtn commentsApp__BoxOption--report commentsApp__interactiveEl" data-action="report">Zgłoś komentarz</button>
                    </div>
                </div>
            </div>
            <div class="commentsApp__commentBody">a gdzie Nobel dla polskich bestii z SG i rzadu za  wypychanie nedzarzy na gola ziemie, chlod glod i choroby ?<br>
przeciez wypychanie to tez fizyka</div>
            <div class="commentsApp__commentFooter">
                <div class="commentsApp__votes">
                    <div class="commentsApp__votesInfo">Aby ocenić <a href="#" class="commentsApp__interactiveEl" data-action="popupVote" data-oxx="62795864">zaloguj się</a> lub <a href="https://konto.gazeta.pl/konto/rejestracja,.html?back=https://next.gazeta.pl/next/7,172690,27650905,nagroda-nobla-2021-akademia-oglosila-nazwiska-laureatow-w-dziedzinie.html">zarejestruj</a> <span class="commentsApp__votesInfo--close commentsApp__interactiveEl" data-action="votesInfoClose">✖</span></div>
                    <button id="voteUpLogged62795864" type="button" class="commentsApp__vote commentsApp__vote--up commentsApp__vote--logged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="voteUp"><svg class="commentsApp__voteSVG commentsApp__vodeSVG--up commentsApp__interactiveEl" data-action="voteUp" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="voteUp" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="voteUp" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M1,14.333H3.667v-8H1ZM15.667,7a1.337,1.337,0,0,0-1.333-1.333H10.127L10.76,2.62l.02-.213a1,1,0,0,0-.293-.707L9.78,1,5.393,5.393A1.3,1.3,0,0,0,5,6.333V13a1.337,1.337,0,0,0,1.333,1.333h6a1.324,1.324,0,0,0,1.227-.813l2.013-4.7a1.317,1.317,0,0,0,.093-.487Z" transform="translate(-0.333 -0.333)"></path></svg> <span id="plusVoteA_62795864">13</span></button>
                    <button id="voteDownLogged62795864" type="button" class="commentsApp__vote commentsApp__vote--down commentsApp__vote--logged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="voteDown"><svg class="commentsApp__voteSVG commentsApp__vodeSVG--down commentsApp__interactiveEl" data-action="voteDown" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="voteDown" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="voteDown" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M10.333,3h-6a1.324,1.324,0,0,0-1.227.813l-2.013,4.7A1.317,1.317,0,0,0,1,9v1.333a1.337,1.337,0,0,0,1.333,1.333H6.54l-.633,3.047-.02.213a1,1,0,0,0,.293.707l.707.7L11.28,11.94a1.325,1.325,0,0,0,.387-.94V4.333A1.337,1.337,0,0,0,10.333,3ZM13,3v8h2.667V3Z" transform="translate(-0.333 -1)"></path></svg> <span id="minusVoteA_62795864">5</span></button>
                    <button id="voteUpLoggedOut62795864" title="Aby ocenić zaloguj się lub zarejestruj" type="button" class="commentsApp__vote commentsApp__vote--up commentsApp__vote--unlogged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="votesInfo"><svg data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVG commentsApp__vodeSVG--up" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M1,14.333H3.667v-8H1ZM15.667,7a1.337,1.337,0,0,0-1.333-1.333H10.127L10.76,2.62l.02-.213a1,1,0,0,0-.293-.707L9.78,1,5.393,5.393A1.3,1.3,0,0,0,5,6.333V13a1.337,1.337,0,0,0,1.333,1.333h6a1.324,1.324,0,0,0,1.227-.813l2.013-4.7a1.317,1.317,0,0,0,.093-.487Z" transform="translate(-0.333 -0.333)"></path></svg> <span id="plusVoteB_62795864">13</span></button>
                    <button id="voteDownLoggedOut62795864" title="Aby ocenić zaloguj się lub zarejestruj" type="button" class="commentsApp__vote commentsApp__vote--down commentsApp__vote--unlogged commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="votesInfo"><svg data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVG commentsApp__vodeSVG--down" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--transparent" d="M0,0H16V16H0Z"></path><path data-action="votesInfo" class="commentsApp__interactiveEl commentsApp__voteSVGPath commentsApp__voteSVGPath--fill" d="M10.333,3h-6a1.324,1.324,0,0,0-1.227.813l-2.013,4.7A1.317,1.317,0,0,0,1,9v1.333a1.337,1.337,0,0,0,1.333,1.333H6.54l-.633,3.047-.02.213a1,1,0,0,0,.293.707l.707.7L11.28,11.94a1.325,1.325,0,0,0,.387-.94V4.333A1.337,1.337,0,0,0,10.333,3ZM13,3v8h2.667V3Z" transform="translate(-0.333 -1)"></path></svg> <span id="minusVoteB_62795864">5</span></button>
                </div>
                <button type="button" class="commentsApp__reply commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="reply">Odpowiedz</button>

                <button type="button" class="commentsApp__showReplies commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="showReplies"><span class="commentsApp__showRepliesText commentsApp__interactiveEl" data-action="showReplies">Pokaż odpowiedzi</span> (5)</button>

            </div>

        <form class="commentsApp__textField">
            <textarea data-oxx="62795864" class="commentsApp__addCommentTextarea commentsApp__interactiveEl commentsApp__addCommentTextarea--revealBottom" placeholder="Dodaj komentarz..." data-action="revealBottom" rows="1"></textarea>
            <div class="commentsApp__bottom">
                <div class="commentsApp__bottomFrame commentsApp__interactiveEl" data-action="showChangeButton">
                    <div class="commentsApp__bottomFrameElement commentsApp__userName commentsApp__interactiveEl" data-action="showChangeButton"></div>
                    <button class="commentsApp__textStyledBtn commentsApp__change commentsApp__interactiveEl" data-action="popupChange" data-oxx="62795864">Zmień</button>
                </div>
                <div>
                    <button onmouseover="this.focus()" data-oxx="62795864" type="button" class="commentsApp__button commentsApp__button--login commentsApp__interactiveEl" data-action="popup">Zaloguj się i skomentuj</button>
                    <button onmouseover="this.focus()" data-oxx="62795864" type="button" class="commentsApp__button commentsApp__button--send commentsApp__interactiveEl" data-action="send">Skomentuj</button>
                </div>
            </div>
            <input type="hidden" name="OXX" value="62795864">
        </form>
        <div class="commentsApp__infoMessage" data-message="62795864"><span class="commentsApp__infoMessageText"></span><span data-action="closeMessage" class="commentsApp__interactiveEl commentsApp__infoMessageClose">✖</span></div>

            <div class="commentsApp__subComments"></div>
        </div>

        </div>


    <div class="commentsApp__loadMore">
        <button type="button" class="commentsApp__button commentsApp__buttonLoadMore commentsApp__interactiveEl" data-action="loadMore" data-count="0">Wczytaj więcej komentarzy</button>
    </div>


    <div class="commentsApp__popupOverlay commentsApp__interactiveEl" data-action="closePopup"></div>
    <div class="commentsApp__popup commentsApp__popup--login">
        <form class="commentsApp__popupInner commentsApp__popupForm--login">
            <button type="button" class="commentsApp__popupClose commentsApp__textStyledBtn commentsApp__interactiveEl" data-action="closePopup">
                <svg class="commentsApp__popupCloseSVG commentsApp__interactiveEl" data-action="closePopup" xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 14 14"><path data-action="closePopup" class="commentsApp__popupCloseSVGPath commentsApp__interactiveEl" d="M19,6.4,17.6,5,12,10.6,6.4,5,5,6.4,10.6,12,5,17.6,6.4,19,12,13.4,17.6,19,19,17.6,13.4,12Z" transform="translate(-5 -5)"></path></svg>
            </button>
            <span class="commentsApp__popupHeader">Zaloguj się kontem gazeta.pl</span>
            <p class="commentsApp__popupInfo">Jeżeli nie masz jeszcze konta <a href="https://konto.gazeta.pl/konto/szybka-rejestracja.do" class="commentsApp__popupLink" rel="nofollow" title="Zarejestruj się">zarejestruj się</a></p>
            <div class="commentsApp__popupInputErrorTop"></div>
            <div class="commentsApp__popupInputContainer">
                <input id="commentsApp__username" class="commentsApp__popupInput commentsApp__popupInput--username" type="text" name="username" placeholder="e-mail lub login">
                <div id="commentsApp__usernameError" class="commentsApp__popupInputError">Wpisz swój e-mail lub login</div>
            </div>
            <div class="commentsApp__popupInputContainer">
                <input id="commentsApp__password" class="commentsApp__popupInput commentsApp__popupInput--password" type="password" name="password" placeholder="hasło">
                <div id="commentsApp__passwordError" class="commentsApp__popupInputError">Wpisz swoje hasło</div>
            </div>
            <div class="commentsApp__popupInputContainer commentsApp__popupInputContainer--memory">
                <div class="commentsApp__remember">
                    <label class="commentsApp__label" for="rememberme">
                        <input class="commentsApp__checkbox commentsApp__interactiveEl" type="checkbox" id="rememberme" name="rememberme" value="1" data-action="rememberme">
                        <label class="commentsApp__fakeCheckbox" for="rememberme"><div class="commentsApp__fakeCheckbox-span">Zapamiętaj mnie</div></label>
                    </label>
                </div>
                <div class="commentsApp__remind">
                    <a target="_blank" class="commentsApp__popupLink" href="https://konto.gazeta.pl/konto/3481802,2,,,,,,3.html" rel="nofollow" title="Nie pamiętasz hasła?">Nie pamiętasz hasła?</a>
                </div>
            </div>
            <div class="commentsApp__submit commentsApp__submit--login">
                <button type="submit" class="commentsApp__button commentsApp__button--login commentsApp__interactiveEl" data-action="login">Zaloguj się</button>
            </div>

        </form>
    </div>


</div>
                    </div>
                    <div class="right_aside">
                        <div id="adUnit-067-RECTANGLE-BTF" class="adviewDFPBanner DFP-067-RECTANGLE-BTF activeBan" data-google-query-id="COSth7mzs_MCFQQF5godz2oIjA" style="margin-left: auto; margin-right: auto; min-width: 300px; max-width: 300px;">


    <span class="banLabel" style="display: block; max-width: 300px; margin-left: auto; margin-right: auto;">REKLAMA</span><div id="google_ads_iframe_/75224259/AGORA-IN/Next/067-RECTANGLE-BTF_0__container__" style="border: 0pt none; display: inline-block; width: 300px; height: 250px;"><iframe frameborder="0" src="https://945d610509ca599ab5d9a913eec7b95a.safeframe.googlesyndication.com/safeframe/1-0-38/html/container.html" id="google_ads_iframe_/75224259/AGORA-IN/Next/067-RECTANGLE-BTF_0" title="3rd party ad content" name="" scrolling="no" marginwidth="0" marginheight="0" width="300" height="250" data-is-safeframe="true" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" data-google-container-id="d" style="border: 0px; vertical-align: bottom;" data-load-complete="true"></iframe></div></div>
<!-- v1.0 -->
<!--410356621, [ /tpl/ads/prod/dfpSlotScripts.jsp ], dfpBanersSlotScriptsBean-->
<!-- v2.2.2 -->
<!--410356671, [ /tpl/ads/prod/dfpSlot.jsp ], dfpBanersSlotBean-->
</div>
                </div>
            </div> <!-- .content_wrap -->
</div>
</template>


<script>
export default {
    props: ['test']
}
</script>