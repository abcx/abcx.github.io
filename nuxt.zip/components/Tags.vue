<template>
    <section class="tags">
        <header class="tags_header">Więcej o:</header>
        <ul class="tags_list">
            <li class="tags_item" v-for="tag in data.tags" :key="tag.tag">
                <a :href="tag.url" :title="tag.title" class="tag_link">{{tag.title}}</a>
            </li>
            </ul>
    </section>
</template>


<script>
export default {
    props: ['data']
}
</script>