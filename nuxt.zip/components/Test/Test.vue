<template src="./template.html"/>
<style lang="scss" src="./style.scss"/>
<script lang="ts" src="./component.ts" />