export default {
    // Global page headers: https://go.nuxtjs.dev/config-head
    head: {
      title: 'Next.pl'
    }
}