import Head from 'next/head';
import Header from '../components/Header';
import Article from '../components/Article';
import data from '../../../vue-nuxt/article.json';
import Aside from '../components/Aside';
import Bottom from '../components/Bottom';
import BoxSeo from '../components/BoxSeo';
import Footer from '../components/Footer';

export default function Home() {
  return (
    <div className="container">
      <Head>
        <title>Create Next App</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=yes"/>
        <link rel="icon" href="/favicon.ico" />
        <link rel="stylesheet" href="https://static.im-g.pl/style-modules/master/webpack/Next/218/pagetype7/style-desk-min.css.cssgz?t=1633000944041"/>
      </Head>

      <Header/>
      <Article {...data}/>
      <Aside/>
      <Bottom/>
      <BoxSeo/>
      <Footer/>

      <style>{`
#onn-player__player {display:none}
      `}</style>
    </div>
  )
}
