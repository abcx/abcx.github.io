export default function Tags({ ...props }) {

    return (
<section className="tags">
        <header className="tags_header">Więcej o:</header>
        <ul className="tags_list">
            {props.tags.map(tag => (
                <li className="tags_item">
                    {tag.url
                    ? <a href={tag.url} title={tag.title} className="tag_link">{tag.title}</a>
                    : <span>{tag.title}</span>}
                </li>
            ))}
        </ul>
      </section>
  );
};