export const Breadcrumbs = props => {

    return (
    <div id="sitePath">
        <ul id="breadcrumbs" data-bd-viewability-id="breadcrumbs" data-bd-viewability="1">
            {props.breadcrumbs.map(bc => (
                <li className="bc_item">
                    {bc.url
                    ? <a href="bc.url" title="bc.title" className="bc_item_link">{bc.title}</a>
                    : <span>{bc.title}</span>}
                </li>
            ))}
        </ul>
    </div>
  );
};