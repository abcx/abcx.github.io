export default function Footer({ ...props }) {

    return (
<footer className="page_footer">
        <div className="page_footer_upper">
          <ul className="footer_upper_links">
            <li>
              <a href="https://www.sport.pl/sport-hp/0,0.html#e=GFootLink" title="Sport" data-bd-viewability-id="footerUpper" data-bd-viewability-href="https://www.sport.pl/sport-hp/0,0.html#e=GFootLink" data-bd-viewability={1}>Sport</a>
            </li><li>
              <a href="https://www.edziecko.pl/edziecko/0,0.html#e=GFootLink" title="Dziecko" data-bd-viewability-id="footerUpper" data-bd-viewability-href="https://www.edziecko.pl/edziecko/0,0.html#e=GFootLink" data-bd-viewability={1}>Dziecko</a>
            </li><li>
              <a href="https://www.tokfm.pl/Tokfm/0,0.html#e=GFootLink" title="TOK FM" data-bd-viewability-id="footerUpper" data-bd-viewability-href="https://www.tokfm.pl/Tokfm/0,0.html#e=GFootLink" data-bd-viewability={1}>TOK FM</a>
            </li><li>
              <a href="https://horoskopy.gazeta.pl/horoskop/0,0.html#e=GFootLink" title="Horoskopy" data-bd-viewability-id="footerUpper" data-bd-viewability-href="https://horoskopy.gazeta.pl/horoskop/0,0.html#e=GFootLink" data-bd-viewability={1}>Horoskopy</a>
            </li><li>
              <a href="http://wyborcza.pl/0,0.html#e=GFootLink" title="Gazeta Wyborcza" data-bd-viewability-id="footerUpper" data-bd-viewability-href="http://wyborcza.pl/0,0.html#e=GFootLink" data-bd-viewability={1}>Gazeta Wyborcza</a>
            </li><li>
              <a href="https://avanti24.pl/Avanti/0,0.html#e=GFootLink" title="Zakupy" data-bd-viewability-id="footerUpper" data-bd-viewability-href="https://avanti24.pl/Avanti/0,0.html#e=GFootLink" data-bd-viewability={1}>Zakupy</a>
            </li><li>
              <a href="https://haps.pl/Haps/0,0.html#e=GFootLink" title="Haps" data-bd-viewability-id="footerUpper" data-bd-viewability-href="https://haps.pl/Haps/0,0.html#e=GFootLink" data-bd-viewability={1}>Haps</a>
            </li><li>
              <a href="https://wiadomosci.gazeta.pl/wiadomosci/0,0.html#e=GFootLink" title="Wiadomości" data-bd-viewability-id="footerUpper" data-bd-viewability-href="https://wiadomosci.gazeta.pl/wiadomosci/0,0.html#e=GFootLink" data-bd-viewability={1}>Wiadomości</a>
            </li><li>
              <a href="https://www.gazeta.pl/0,0.html#e=GFootLink" title="Gazeta.pl" data-bd-viewability-id="footerUpper" data-bd-viewability-href="https://www.gazeta.pl/0,0.html#e=GFootLink" data-bd-viewability={1}>Gazeta.pl</a>
            </li>
          </ul>
          <ul className="footer_middle_links">
            <li>
              <a href="https://oauth.gazeta.pl/poczta/auth" title="Poczta" data-bd-viewability-id="footerMiddle" data-bd-viewability-href="https://oauth.gazeta.pl/poczta/auth" data-bd-viewability={1}>Poczta</a>
            </li><li>
              <a href="https://newslettery.gazeta.pl/newslettery" title="Newsletter" data-bd-viewability-id="footerMiddle" data-bd-viewability-href="https://newslettery.gazeta.pl/newslettery" data-bd-viewability={1}>Newsletter</a>
            </li><li>
              <a href="https://next.gazeta.pl/next/3660000,0.html" title="Wszystkie artykuły" data-bd-viewability-id="footerMiddle" data-bd-viewability-href="https://next.gazeta.pl/next/3660000,0.html" data-bd-viewability={1}>Wszystkie artykuły</a>
            </li><li>
              <a href="https://www.facebook.com/gazetapl?ref=ts" title="Facebook" data-bd-viewability-id="footerMiddle" data-bd-viewability-href="https://www.facebook.com/gazetapl?ref=ts" data-bd-viewability={1}>Facebook</a>
            </li>
          </ul>
        </div>
        <a href="https://www.agora.pl/#e=AFootLink" target="_blank" rel="noreferrer" data-bd-viewability-id="footerLower" data-bd-viewability-href="https://www.agora.pl/#e=AFootLink" data-bd-viewability={1}>Copyright © Agora SA</a>
        <ul className="footer_lower_links">
          <li>
            <a href="https://next.gazeta.pl/pub/next/rssnext.htm#e=AFootLink" title="RSS" data-bd-viewability-id="footerLower" data-bd-viewability-href="https://next.gazeta.pl/pub/next/rssnext.htm#e=AFootLink" data-bd-viewability={1}>RSS</a>
          </li><li>
            <a href="https://onas.gazeta.pl#e=AFootLink" title="O Nas" data-bd-viewability-id="footerLower" data-bd-viewability-href="https://onas.gazeta.pl#e=AFootLink" data-bd-viewability={1}>O Nas</a>
          </li><li>
            <a href="https://reklama.gazeta.pl#e=AFootLink" title="Reklama" data-bd-viewability-id="footerLower" data-bd-viewability-href="https://reklama.gazeta.pl#e=AFootLink" data-bd-viewability={1}>Reklama</a>
          </li><li>
            <a href="https://pomoc.gazeta.pl/pomoc/7,154322,8856779,ochrona-prywatnosci.html#e=AFootLink" title="Prywatność" data-bd-viewability-id="footerLower" data-bd-viewability-href="https://pomoc.gazeta.pl/pomoc/7,154322,8856779,ochrona-prywatnosci.html#e=AFootLink" data-bd-viewability={1}>Prywatność</a>
          </li>
          <li>
            <a data-error-node href="http://pomoc.gazeta.pl/zglos_blad/0,0.html?sv=https://next.gazeta.pl/next/7,172690,27650905,nagroda-nobla-2021-akademia-oglosila-nazwiska-laureatow-w-dziedzinie.html" data-width={650} data-height={505} title="Zgłoś błąd">Zgłoś błąd</a>
          </li>
          <li id="footer_consent_link" onclick="OneTrust.ToggleInfoDisplay()"><a href="javascript:void(0)">Zgody</a></li></ul>
      </footer>
  );
};