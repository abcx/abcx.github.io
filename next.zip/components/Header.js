import React from 'react';
// import Head from 'next/head'
// import Image from 'next/image'
// import styles from './layout.module.css'
// import utilStyles from '../styles/utils.module.css'
// import Link from 'next/link'

// const name = 'Your Name'
// export const siteTitle = 'Next.js Sample Website'

export default class App extends React.Component {
    render() {
      return (

        <div className="top_wrapper navigationWithAdsPass">
          <div id="DFP_PREMIUMBOARD" className="DFPbannerPartnerWrapper DFP-premiumBoardReservedPlace" style={{backgroundColor: '#fff'}} />
          {/* hat_2021_desktop v0.12 isShutDown:false/aliasy/cap/next */}
          <header className="main-navigation">
            <div className="main-navigation__outer-nav">
              <div className="main-navigation__inner-wrapper">
                <div className="main-navigation__logo">
                  <a href="https://www.gazeta.pl/0,0.html#e=CapLogoG" id="LinkArea:CapLogoG" title="GAZETA.pl - Wiadomości, Rozrywka, Forum, Poczta">
                    <svg className="main-navigation__icon" x="0px" y="0px" viewBox="0 0 254 60" style={{enableBackground: 'new 0 0 254 60'}} xmlSpace="preserve">
                      <g><linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="72.128" y1="51.3644" x2="10.1928" y2="-10.5708"><stop offset={0} style={{stopColor: '#FF4282'}} /><stop offset="0.1292" style={{stopColor: '#FF3365'}} /><stop offset="0.4085" style={{stopColor: '#FF0D1A'}} /><stop offset="0.5" style={{stopColor: '#FF0000'}} /><stop offset="0.7076" style={{stopColor: '#FF361F'}} /><stop offset="0.9019" style={{stopColor: '#FF6238'}} /><stop offset={1} style={{stopColor: '#FF7342'}} /></linearGradient><path style={{fill: 'url(#SVGID_1_)'}} d="M20.8,9.5C20.8,4.3,25,0,30.3,0c5.3,0,9.5,4.3,9.5,9.5c0,5.3-4.3,9.5-9.5,9.5C25,19,20.8,14.8,20.8,9.5z" /><linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="72.1275" y1="51.3638" x2="10.1923" y2="-10.5714"><stop offset={0} style={{stopColor: '#FF4282'}} /><stop offset="0.1292" style={{stopColor: '#FF3365'}} /><stop offset="0.4085" style={{stopColor: '#FF0D1A'}} /><stop offset="0.5" style={{stopColor: '#FF0000'}} /><stop offset="0.7076" style={{stopColor: '#FF361F'}} /><stop offset="0.9019" style={{stopColor: '#FF6238'}} /><stop offset={1} style={{stopColor: '#FF7342'}} /></linearGradient><path style={{fill: 'url(#SVGID_2_)'}} d="M42.4,31.1c0-5.3,4.3-9.5,9.5-9.5c5.3,0,9.5,4.3,9.5,9.5c0,5.3-4.3,9.5-9.5,9.5C46.7,40.7,42.4,36.4,42.4,31.1 z" /><linearGradient id="SVGID_3_" gradientUnits="userSpaceOnUse" x1="50.5704" y1="73.0665" x2="-11.3606" y2="11.1355"><stop offset={0} style={{stopColor: '#FF4282'}} /><stop offset="0.1292" style={{stopColor: '#FF3365'}} /><stop offset="0.4085" style={{stopColor: '#FF0D1A'}} /><stop offset="0.5" style={{stopColor: '#FF0000'}} /><stop offset="0.7076" style={{stopColor: '#FF361F'}} /><stop offset="0.9019" style={{stopColor: '#FF6238'}} /><stop offset={1} style={{stopColor: '#FF7342'}} /></linearGradient><path style={{fill: 'url(#SVGID_3_)'}} d="M0,31.1c0-4.8,3.9-8.7,8.7-8.7c4.8,0,8.7,3.9,8.7,8.7c0,4.8-3.9,8.7-8.7,8.7C3.9,39.8,0,35.9,0,31.1z" /><linearGradient id="SVGID_4_" gradientUnits="userSpaceOnUse" x1="61.3483" y1="62.2143" x2="-0.5841" y2="0.2819"><stop offset={0} style={{stopColor: '#FF4282'}} /><stop offset="0.1292" style={{stopColor: '#FF3365'}} /><stop offset="0.4085" style={{stopColor: '#FF0D1A'}} /><stop offset="0.5" style={{stopColor: '#FF0000'}} /><stop offset="0.7076" style={{stopColor: '#FF361F'}} /><stop offset="0.9019" style={{stopColor: '#FF6238'}} /><stop offset={1} style={{stopColor: '#FF7342'}} /></linearGradient><path style={{fill: 'url(#SVGID_4_)'}} d="M0.9,9.5c0-4.3,3.5-7.8,7.8-7.8c4.3,0,7.8,3.5,7.8,7.8c0,4.3-3.5,7.8-7.8,7.8C4.4,17.3,0.9,13.8,0.9,9.5z" /><linearGradient id="SVGID_5_" gradientUnits="userSpaceOnUse" x1="61.3428" y1="62.2088" x2="-0.5903" y2="0.2757"><stop offset={0} style={{stopColor: '#FF4282'}} /><stop offset="0.1292" style={{stopColor: '#FF3365'}} /><stop offset="0.4085" style={{stopColor: '#FF0D1A'}} /><stop offset="0.5" style={{stopColor: '#FF0000'}} /><stop offset="0.7076" style={{stopColor: '#FF361F'}} /><stop offset="0.9019" style={{stopColor: '#FF6238'}} /><stop offset={1} style={{stopColor: '#FF7342'}} /></linearGradient><path style={{fill: 'url(#SVGID_5_)'}} d="M44.8,52.8c0-3.9,3.2-7.1,7.1-7.1c3.9,0,7.1,3.2,7.1,7.1c0,3.9-3.2,7.1-7.1,7.1C48,59.9,44.8,56.7,44.8,52.8z" /><linearGradient id="SVGID_6_" gradientUnits="userSpaceOnUse" x1="82.8997" y1="40.506" x2="20.9658" y2="-21.4278"><stop offset={0} style={{stopColor: '#FF4282'}} /><stop offset="0.1292" style={{stopColor: '#FF3365'}} /><stop offset="0.4085" style={{stopColor: '#FF0D1A'}} /><stop offset="0.5" style={{stopColor: '#FF0000'}} /><stop offset="0.7076" style={{stopColor: '#FF361F'}} /><stop offset="0.9019" style={{stopColor: '#FF6238'}} /><stop offset={1} style={{stopColor: '#FF7342'}} /></linearGradient><path style={{fill: 'url(#SVGID_6_)'}} d="M47.2,9.5c0-2.6,2.1-4.8,4.8-4.8c2.6,0,4.8,2.1,4.8,4.8c0,2.6-2.1,4.8-4.8,4.8C49.3,14.3,47.2,12.1,47.2,9.5z" /><linearGradient id="SVGID_7_" gradientUnits="userSpaceOnUse" x1="39.7954" y1="83.9211" x2="-22.1384" y2="21.9872"><stop offset={0} style={{stopColor: '#FF4282'}} /><stop offset="0.1292" style={{stopColor: '#FF3365'}} /><stop offset="0.4085" style={{stopColor: '#FF0D1A'}} /><stop offset="0.5" style={{stopColor: '#FF0000'}} /><stop offset="0.7076" style={{stopColor: '#FF361F'}} /><stop offset="0.9019" style={{stopColor: '#FF6238'}} /><stop offset={1} style={{stopColor: '#FF7342'}} /></linearGradient><path style={{fill: 'url(#SVGID_7_)'}} d="M3.9,52.8C3.9,50.2,6,48,8.6,48c2.6,0,4.8,2.1,4.8,4.8c0,2.6-2.1,4.8-4.8,4.8C6,57.5,3.9,55.4,3.9,52.8z" /><linearGradient id="SVGID_8_" gradientUnits="userSpaceOnUse" x1="61.3583" y1="62.2214" x2="-0.578" y2="0.2851"><stop offset={0} style={{stopColor: '#FF4282'}} /><stop offset="0.1292" style={{stopColor: '#FF3365'}} /><stop offset="0.4085" style={{stopColor: '#FF0D1A'}} /><stop offset="0.5" style={{stopColor: '#FF0000'}} /><stop offset="0.7076" style={{stopColor: '#FF361F'}} /><stop offset="0.9019" style={{stopColor: '#FF6238'}} /><stop offset={1} style={{stopColor: '#FF7342'}} /></linearGradient><path style={{fill: 'url(#SVGID_8_)'}} d="M24.2,31.1c0-3.3,2.7-6.1,6.1-6.1c3.3,0,6.1,2.7,6.1,6.1c0,3.3-2.7,6.1-6.1,6.1C26.9,37.2,24.2,34.5,24.2,31.1 z" /><linearGradient id="SVGID_9_" gradientUnits="userSpaceOnUse" x1="50.5888" y1="73.0816" x2="-11.3421" y2="11.1508"><stop offset={0} style={{stopColor: '#FF4282'}} /><stop offset="0.1292" style={{stopColor: '#FF3365'}} /><stop offset="0.4085" style={{stopColor: '#FF0D1A'}} /><stop offset="0.5" style={{stopColor: '#FF0000'}} /><stop offset="0.7076" style={{stopColor: '#FF361F'}} /><stop offset="0.9019" style={{stopColor: '#FF6238'}} /><stop offset={1} style={{stopColor: '#FF7342'}} /></linearGradient><path style={{fill: 'url(#SVGID_9_)'}} d="M24,52.8c0-3.5,2.8-6.3,6.3-6.3c3.5,0,6.3,2.8,6.3,6.3c0,3.5-2.8,6.3-6.3,6.3C26.8,59,24,56.2,24,52.8z" /><path d="M98.8,32.2h-8.2v-1.8h10.2v1.3c0,6.3-3.6,10.3-9.6,10.3c-6.6,0-10.7-4.7-10.7-10.8c0-6.2,4.2-10.9,10.8-10.9 c5.3,0,7.6,2.8,7.6,2.8l-1.1,1.5c0,0-2.2-2.4-6.5-2.4c-5.5,0-8.8,4.1-8.8,9c0,4.9,3.2,9,8.7,9c4.6,0,7.6-3,7.6-7.7V32.2z" /><path d="M113.6,20.8h0.5l10.1,20.8H122l-2-3.9h-12.3l-2,3.9h-2.2L113.6,20.8z M114,24.8h-0.3l-4.8,10.6l-0.2,0.4h10.4l-0.2-0.4 L114,24.8z" /><path d="M127.2,41.1l13.3-18.4h-12.9v-1.8h16.2v0.5l-13.1,18.4h12.8v1.8h-16.2V41.1z" /><path d="M162.9,32.2h-11.5v7.5h13v1.8h-15V20.8h15v1.8h-13v7.8h11.5V32.2z" /><path d="M168.2,20.8H185v1.8h-7.4v18.9h-1.9V22.6h-7.4V20.8z" /><path d="M195.3,20.8h0.5l10.1,20.8h-2.2l-2-3.9h-12.3l-2,3.9h-2.2L195.3,20.8z M195.7,24.8h-0.3l-4.8,10.6l-0.2,0.4h10.4l-0.2-0.4 L195.7,24.8z" /><path d="M210.1,38.9c0.8,0,1.5,0.7,1.5,1.5c0,0.8-0.6,1.5-1.5,1.5c-0.8,0-1.5-0.7-1.5-1.5C208.6,39.5,209.3,38.9,210.1,38.9z" /><path d="M217.2,20.8h8.3c5.2,0,8.2,2.4,8.2,6.9c0,4.7-3.2,7.1-8.3,7.1h-6.2v6.8h-2V20.8z M225.4,22.6h-6.3v10.3h6.3 c3.8,0,6.3-1.5,6.3-5.2C231.7,24.2,229.2,22.6,225.4,22.6z" /><path d="M239.6,41.6V20.8h2v18.9H254v1.8H239.6z" /></g>
                    </svg>
                  </a>
                </div>
                <nav className="main-navigation__nav">
                  <ul className="main-navigation__lists">
                    <li className="main-navigation__list-item ">
                      <a className="main-navigation__link" href="https://wiadomosci.gazeta.pl/wiadomosci/0,0.html#e=CapLinks" id="LinkArea:CapLinks" title="WIADOMOŚCI">
                        WIADOMOŚCI
                      </a>
                    </li>
                    <li className="main-navigation__list-item main-navigation__list-item--isHighlighted">
                      <a className="main-navigation__link" href="https://next.gazeta.pl/next/0,0.html#e=CapLinks" id="LinkArea:CapLinks" title="NEXT">
                        NEXT
                      </a>
                    </li>
                    <li className="main-navigation__list-item ">
                      <a className="main-navigation__link" href="https://www.sport.pl/sport-hp/0,0.html#e=CapLinks" id="LinkArea:CapLinks" title="SPORT">
                        SPORT
                      </a>
                    </li>
                    <li className="main-navigation__list-item ">
                      <a className="main-navigation__link" href="https://www.plotek.pl/plotek/0,0.html#e=CapLinks" id="LinkArea:CapLinks" title="PLOTEK">
                        PLOTEK
                      </a>
                    </li>
                    <li className="main-navigation__list-item ">
                      <a className="main-navigation__link" href="https://www.edziecko.pl/edziecko/0,0.html#e=CapLinks" id="LinkArea:CapLinks" title="DZIECKO">
                        DZIECKO
                      </a>
                    </li>
                    <li className="main-navigation__dropdown">
                      <span className="main-navigation__arrow-small js-trigger-main-navigation__show" />
                    </li>
                  </ul>
                </nav>
                <nav className="main-navigation__shortcuts">
                  <ul className="main-navigation__lists">
                    <li className="main-navigation__list-item main-navigation__list-item--mail">
                      <a className="main-navigation__link" href="http://poczta.gazeta.pl#e=CapIco" id="LinkArea:CapIco" title="poczta">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" width={20} height={20} viewBox="0 0 24 24"><defs> <style dangerouslySetInnerHTML={{__html: ".pocztaA {fill: #444; }.pocztaB {clip-path: url(#pocztaA);}.pocztaC {fill: none; }" }} /><clipPath id="pocztaA"> <rect className="pocztaA" width={24} height={24} transform="translate(1300 29)" /></clipPath></defs> <g className="pocztaB" transform="translate(-1300 -29)"><g transform="translate(1300 29)"><path className="pocztaC" d="M0,0H24V24H0Z" /><path className="pocztaA" d="M20,4H4A2,2,0,0,0,2.01,6L2,18a2.006,2.006,0,0,0,2,2H20a2.006,2.006,0,0,0,2-2V6A2.006,2.006,0,0,0,20,4Zm0,14H4V8l8,5,8-5Zm-8-7L4,6H20Z" /></g></g></svg>
                        <span className="main-navigation__svg-name">poczta</span>
                      </a>
                    </li>
                    <li className="main-navigation__list-item main-navigation__list-item--forum">
                      <a className="main-navigation__link" href="https://forum.gazeta.pl#e=CapIco" id="LinkArea:CapIco" title="Forum">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" width={20} height={20} viewBox="0 0 24 24"><defs><style dangerouslySetInnerHTML={{__html: ".forumA,.forumC { fill: #444; }.forumB {clip-path: url(#forumA); }.forumC { stroke: #444; stroke-width: 0.3px;}" }} /><clipPath id="forumA"> <rect className="forumA" width={24} height={24} transform="translate(1370 29)" /></clipPath></defs><g className="forumB" transform="translate(-1370 -29)"><g transform="translate(1372 31)"><path className="forumC" d="M18.8,5.7h-.75V7.367h.75a.538.538,0,0,1,.5.5v9l-1-1.083-.5-.5H7.967a.538.538,0,0,1-.5-.5v-.75H5.8v.75A2.206,2.206,0,0,0,7.967,16.95h9.167l3.833,4V7.867A2.152,2.152,0,0,0,18.8,5.7Z" transform="translate(-0.967 -0.95)" /> <path className="forumC" d="M13.083,11.25A2.206,2.206,0,0,0,15.25,9.083V1.833A2.158,2.158,0,0,0,13.083,0H2.167A2.206,2.206,0,0,0,0,2.167V15.25l2.5-2.5,1.417-1.5h9.167ZM2.667,10.083,1.75,11l-.083.167v-9a.538.538,0,0,1,.5-.5H13.083a.433.433,0,0,1,.333.167.632.632,0,0,1,.167.333V9.083a.538.538,0,0,1-.5.5H3.167Z" /></g></g></svg>
                        <span className="main-navigation__svg-name">Forum</span>
                      </a>
                    </li>
                    <li className="main-navigation__list-item main-navigation__list-item--environment">
                      <a className="main-navigation__link" href="https://zielona.gazeta.pl/zielona_gazeta/0,0.html#e=CapIco" id="LinkArea:CapIco" title="Środowisko">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" width={20} height={20} viewBox="0 0 24 24"><defs> <style dangerouslySetInnerHTML={{__html: " .srodowiskoA {fill: #fff;}.srodowiskoB {clip-path: url(#srodowiskoA);}" }} /><clipPath id="srodowiskoA"><rect className="srodowiskoA" width={24} height={24} /></clipPath></defs> <g className="srodowiskoB"> <path className="srodowiskoA" d="M23.511,3.526c-.353-.019-8.753-.416-11.958,2.2h0a6.206,6.206,0,0,0-.9,8.63,6.021,6.021,0,0,0,4.722,2.267,6.142,6.142,0,0,0,3.842-1.355c3.2-2.614,4.569-10.981,4.626-11.336l.061-.385Zm-5.717,5-.336-.61a15.944,15.944,0,0,0-5.975,4.457,5.213,5.213,0,0,1-.4-2.807A4.192,4.192,0,0,1,12.552,7.09c2.7-1.848,5.913-1.864,8.751-1.879l.533,0c-.743,3.089-2.3,7.586-3.691,8.745a5,5,0,0,1-3.233.891,4.033,4.033,0,0,1-2.255-.926C13.859,11.409,16.632,9.323,17.794,8.527Z" /> <path className="srodowiskoA" d="M7.908,9.45C6.151,7.617.9,7.048.676,7.025l-.4-.041.009.4c0,.229.143,5.645,1.9,7.483l.013.013a4.085,4.085,0,0,0,5.609-.008A3.872,3.872,0,0,0,7.908,9.45ZM4,10.692l-.568.416a8.426,8.426,0,0,0,2.457,3.107,2.065,2.065,0,0,1-1.061.12,2.151,2.151,0,0,1-1.395-.6A7.923,7.923,0,0,1,2.09,9.248l-.033-.411c1.635.266,3.487.79,4.215,1.543h0a4.157,4.157,0,0,0,.341.312,1.571,1.571,0,0,1,.7,1.363,2.686,2.686,0,0,1-.289,1.079A7.571,7.571,0,0,1,4,10.692Z" /><path className="srodowiskoA" d="M9.553,13.922,9.485,13.9l-.071,0a.731.731,0,0,0-.708.663L7.392,20.709c-.078.487.488.958.8,1.009a.525.525,0,0,0,.079.006,1.474,1.474,0,0,0,.6-.187.9.9,0,0,0,.548-.621l.584-6.079A.754.754,0,0,0,9.553,13.922Z" /></g></svg>
                        <span className="main-navigation__svg-name">Środowisko</span>
                      </a>
                    </li>
                    <li className="main-navigation__list-item main-navigation__list-item--search js-trigger-search-form__show">
                      <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" width={20} height={20} viewBox="0 0 24 24">
                        <defs> <style dangerouslySetInnerHTML={{__html: ".szukajA { fill: #444; }.szukajB { clip-path: url(#szukajA); }.szukajC {  fill: none; }" }} /><clipPath id="szukajA"><rect className="szukajA" width={24} height={24} transform="translate(1560 29)" /> </clipPath></defs>
                        <g className="szukajB" transform="translate(-1560 -29)"><g transform="translate(1560 29)"><path className="szukajC" d="M0,0H24V24H0Z" /><path className="szukajA" d="M15.864,14.321h-.813l-.288-.278a6.7,6.7,0,1,0-.72.72l.278.288v.813L19.467,21,21,19.467Zm-6.175,0A4.631,4.631,0,1,1,14.321,9.69,4.625,4.625,0,0,1,9.69,14.321Z" /></g></g></svg>
                    </li>{/* UZREditor */}{/* htmEOF */}<li className="main-navigation__login main-navigation__list-item">
                      <a href="https://konto.gazeta.pl/konto/logowanie,.html?utm_nooverride=1&back=https://next.gazeta.pl/next/7,151003,27635468,wielka-brytania-zmiany-w-zasadach-wjazdu-od-1-pazdziernika.html#e=CapIco" id="LinkArea:CapIco" title="Zaloguj się" className="main-navigation__login main-navigation__login--logout main-navigation__link">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" width={20} height={20} viewBox="0 0 20 20"><defs><style dangerouslySetInnerHTML={{__html: ".login_a{fill:#444;}.login_b{clip-path:url(#login_a);}" }} /><clipPath id="login_a"><rect className="login_a" width={20} height={20} transform="translate(1649 135)" /></clipPath></defs><g className="login_b" transform="translate(-1649 -135)"><g transform="translate(1651.4 138)"><path className="login_a" d="M7.733,1.68A2.171,2.171,0,0,1,9.88,3.827,2.091,2.091,0,0,1,7.733,5.88,2.154,2.154,0,0,1,5.68,3.733,2.072,2.072,0,0,1,7.733,1.68m0-1.68a3.733,3.733,0,1,0,3.733,3.733A3.744,3.744,0,0,0,7.733,0Z" transform="translate(-0.2)" /><path className="login_a" d="M2.68,13.667a3.107,3.107,0,0,1,3.08-3.08H9.493a3.107,3.107,0,0,1,3.08,3.08V14.6h1.493v-.933A4.621,4.621,0,0,0,9.4,9H5.667A4.621,4.621,0,0,0,1,13.667V14.6H2.68Z" transform="translate(0 -0.6)" /></g></g></svg>
                      </a>
                    </li>
                  </ul>
                  <div className="search-form search-form__hide-element">
                    <form className="search-form__form" action="https://szukaj.gazeta.pl/wyszukaj/artykul">
                      <input className="search-form__input" type="text" placeholder="Szukaj" name="query" />
                      <button className="search-form__submit" type="submit">
                        <svg className="main-navigation__icon" xmlns="http://www.w3.org/2000/svg" width={14} height={14} viewBox="0 0 14 14"><path className="main-navigation__icon" d="M13.006,11.805h-.632l-.224-.216a5.211,5.211,0,1,0-.56.56l.216.224v.632l4,3.994L17,15.807Zm-4.8,0a3.6,3.6,0,1,1,3.6-3.6A3.6,3.6,0,0,1,8.2,11.805Z" transform="translate(-3 -3)" /></svg>
                      </button>
                    </form>
                    <span className="search-form__close">
                      <svg xmlns="http://www.w3.org/2000/svg" width={12} height={12} viewBox="0 0 12 12">
                        <defs><style dangerouslySetInnerHTML={{__html: ".a{fill:#444;}" }} /></defs>
                        <path className="a" d="M17,6.209,15.791,5,11,9.791,6.209,5,5,6.209,9.791,11,5,15.791,6.209,17,11,12.209,15.791,17,17,15.791,12.209,11Z" transform="translate(-5 -5)" /></svg>
                    </span>
                  </div>
                </nav>
              </div>
            </div>{/* UZREditor */}{/* htmEOF */}<div className="navigation-lists__outer-nav">
              <nav className="navigation-lists main-navigation__nav">
                <div className="navigation-lists__row navigation-lists__row--site">
                  <ul className="navigation-lists__lists">
                    <li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="https://kobieta.gazeta.pl/kobieta/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="KOBIETA">KOBIETA</a>
                    </li><li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="https://haps.pl/Haps/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="HAPS">HAPS</a>
                    </li><li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="https://myfitness.gazeta.pl/myfitness/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="MYFITNESS">MYFITNESS</a>
                    </li><li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="https://podroze.gazeta.pl/podroze/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="PODRÓŻE">PODRÓŻE</a>
                    </li><li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="https://horoskopy.gazeta.pl/horoskop/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="HOROSKOPY">HOROSKOPY</a>
                    </li><li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="https://avanti24.pl/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="AVANTI24">AVANTI24</a>
                    </li><li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="https://www.tokfm.pl/Tokfm/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="TOK FM">TOK FM</a>
                    </li><li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="https://pogoda.gazeta.pl/Pogoda/Polska/Warszawa/dzisiaj/48_1000010#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="POGODA">POGODA</a>
                    </li><li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="https://weekend.gazeta.pl/weekend/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="WEEKEND">WEEKEND</a>
                    </li>
                  </ul>
                </div>
                <div className="navigation-lists__row navigation-lists__row--app">
                  <ul className="navigation-lists__lists">
                    <li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="http://aplikacja.gazeta.pl/aplikacjagazeta/#s=NavMoreSeo#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Pobierz naszą aplikację"><svg xmlns="http://www.w3.org/2000/svg" width={20} height={20} viewBox="0 0 20 20"><defs><style dangerouslySetInnerHTML={{__html: ".getApp_a{fill:none;}.getApp_b{fill:#444;}" }} /></defs><path className="getApp_a" d="M0,0H20V20H0Z" /><path className="getApp_b" d="M15,7.588H12.143V3H7.857V7.588H5l5,5.353ZM5,14.471V16H15V14.471Z" /></svg><span>Pobierz naszą aplikację</span></a>
                    </li>
                    <li className="navigation-lists__list-item">
                      <a className="navigation-lists__link" href="https://www.facebook.com/gazetapl/#s=NavMoreSeo#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Zobacz nas na FB"><svg xmlns="http://www.w3.org/2000/svg" width={20} height={20} viewBox="0 0 20 20"><defs><style dangerouslySetInnerHTML={{__html: ".facebook_a{fill:none;}.facebook_b{fill:#444;}" }} /></defs><rect className="facebook_a" width={20} height={20} /><path className="facebook_b" d="M18,9.995A8,8,0,1,0,8.4,17.83V12.393H6.8v-2.4H8.4V8a2.8,2.8,0,0,1,2.8-2.8h2V7.6H11.6a.8.8,0,0,0-.8.8v1.6h2.4v2.4H10.8V17.95A8,8,0,0,0,18,9.995Z" /></svg><span>Zobacz nas na FB</span></a>
                    </li>
                  </ul>
                </div>
                <div className="navigation-lists__row navigation-lists__row--linked">
                  <div className="navigation-lists__group">
                    <div className="navigation-lists__smalltitle">
                      <div className="navigation-lists__smalltitleName">Aktualności</div>
                      <svg className="navigation-lists__smalltitleSVG" xmlns="http://www.w3.org/2000/svg" width={20} height={20} viewBox="0 0 20 20"><defs><style dangerouslySetInnerHTML={{__html: ".arrowDown_a{fill:none;}.arrowDown_b{fill:#444;}" }} /></defs><path className="arrowDown_a" d="M0,0H20V20H0Z" /><path className="arrowDown_b" d="M16.59,8.59,12,13.17,7.41,8.59,6,10l6,6,6-6Z" transform="translate(-2 -2.071)" /></svg>
                    </div>
                    <ul className="navigation-lists__lists">
                      <li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://wiadomosci.gazeta.pl/wiadomosci/0,174110.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Koronawirus statystyki">Koronawirus statystyki</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://wiadomosci.gazeta.pl/wiadomosci/0,173952.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Koronawirus">Koronawirus</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://horoskopy.gazeta.pl/horoskop/0,154827.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Horoskop 2021">Horoskop 2021</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://horoskopy.gazeta.pl/horoskop/0,166543.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Horoskop na dziś">Horoskop na dziś</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://lotto.gazeta.pl/lotto/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Wyniki Lotto">Wyniki Lotto</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://wiadomosci.gazeta.pl/wiadomosci/0,145764.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Najnowsze wiadomości">Najnowsze wiadomości</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://wiadomosci.gazeta.pl/wiadomosci/0,168571.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Na topie">Na topie</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://myfitness.gazeta.pl/myfitness/0,166676.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Newsy Myfitness">Newsy Myfitness</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://haps.pl/Haps/0,167709.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Wiadomości kulinarne">Wiadomości kulinarne</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://haps.pl/Haps/0,168710.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Gazetki Promocyjne">Gazetki Promocyjne</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.plotek.pl/plotek/0,170959.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Wiadomości Plotek">Wiadomości Plotek</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://wiadomosci.gazeta.pl/wiadomosci/0,114916.html?tag=niedziele+handlowe+2021#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Niedziele handlowe">Niedziele handlowe</a>
                      </li>
                    </ul>
                  </div><div className="navigation-lists__group">
                    <div className="navigation-lists__smalltitle">
                      <div className="navigation-lists__smalltitleName">Rozrywka</div>
                      <svg className="navigation-lists__smalltitleSVG" xmlns="http://www.w3.org/2000/svg" width={20} height={20} viewBox="0 0 20 20"><defs><style dangerouslySetInnerHTML={{__html: ".arrowDown_a{fill:none;}.arrowDown_b{fill:#444;}" }} /></defs><path className="arrowDown_a" d="M0,0H20V20H0Z" /><path className="arrowDown_b" d="M16.59,8.59,12,13.17,7.41,8.59,6,10l6,6,6-6Z" transform="translate(-2 -2.071)" /></svg>
                    </div>
                    <ul className="navigation-lists__lists">
                      <li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://buzz.gazeta.pl/buzz/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Buzz Gazeta">Buzz Gazeta</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://radiopogoda.tuba.pl/radiopogoda/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Radio Pogoda">Radio Pogoda</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://fm.tuba.pl/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Radio Internetowe">Radio Internetowe</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://tuba.pl/tubapl/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Muzyka">Muzyka</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://tv.gazeta.pl/program_tv/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Gry online">Gry online</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.plotek.pl/plotek/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Plotek">Plotek</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://kultura.gazeta.pl/kultura/7,114438,25826435,komedie-na-netflixie-ktorych-tytulow-nie-mozesz-przegapic.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Komedie Netflix">Komedie Netflix</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://kultura.gazeta.pl/kultura/7,127222,26885286,netflix-najlepsze-seriale-kryminalne-ranking-10-najlepszych.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Seriale kryminalne Netflix">Seriale kryminalne Netflix</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://kultura.gazeta.pl/kultura/7,114438,26287079,netflix-10-najlepszych-polskich-filmow-te-propozycje-warto.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Polskie filmy Netflix">Polskie filmy Netflix</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://kultura.gazeta.pl/hbo-go#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="HBO GO">HBO GO</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://kultura.gazeta.pl/netflix#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Netflix">Netflix</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://kultura.gazeta.pl/kultura/0,115024.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Festiwale">Festiwale</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.plotek.pl/plotek/0,78882,398208420.html?tag=TVN#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="TVN">TVN</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.plotek.pl/plotek/0,78882,398208420.html?tag=instagram#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Instagram">Instagram</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.plotek.pl/plotek/0,78882,398208420.html?tag=gwiazdy#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Gwiazdy">Gwiazdy</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/gry#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Gry">Gry</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/konsole#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Konsole">Konsole</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/smartfony#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Smartfony">Smartfony</a>
                      </li>
                    </ul>
                  </div><div className="navigation-lists__group">
                    <div className="navigation-lists__smalltitle">
                      <div className="navigation-lists__smalltitleName">Praca</div>
                      <svg className="navigation-lists__smalltitleSVG" xmlns="http://www.w3.org/2000/svg" width={20} height={20} viewBox="0 0 20 20"><defs><style dangerouslySetInnerHTML={{__html: ".arrowDown_a{fill:none;}.arrowDown_b{fill:#444;}" }} /></defs><path className="arrowDown_a" d="M0,0H20V20H0Z" /><path className="arrowDown_b" d="M16.59,8.59,12,13.17,7.41,8.59,6,10l6,6,6-6Z" transform="translate(-2 -2.071)" /></svg>
                    </div>
                    <ul className="navigation-lists__lists">
                      <li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.goldenline.pl/praca/wroclaw/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Praca Wrocław">Praca Wrocław</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.goldenline.pl/praca/poznan/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Praca Poznań">Praca Poznań</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.goldenline.pl/praca/krakow/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Praca Kraków">Praca Kraków</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.goldenline.pl/praca/warszawa/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Praca Warszawa">Praca Warszawa</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.goldenline.pl/praca/lublin/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Praca Lublin">Praca Lublin</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.goldenline.pl/praca/olsztyn/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Praca Olsztyn">Praca Olsztyn</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.goldenline.pl/praca/lodz/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Praca Łódź">Praca Łódź</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.goldenline.pl/praca/bielsko-biala/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Praca Bielsko-Biała">Praca Bielsko-Biała</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.goldenline.pl/praca/radom/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Praca Radom">Praca Radom</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://www.goldenline.pl/praca/walbrzych/#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Praca Wałbrzych">Praca Wałbrzych</a>
                      </li>
                    </ul>
                  </div><div className="navigation-lists__group">
                    <div className="navigation-lists__smalltitle">
                      <div className="navigation-lists__smalltitleName">Zakupy</div>
                      <svg className="navigation-lists__smalltitleSVG" xmlns="http://www.w3.org/2000/svg" width={20} height={20} viewBox="0 0 20 20"><defs><style dangerouslySetInnerHTML={{__html: ".arrowDown_a{fill:none;}.arrowDown_b{fill:#444;}" }} /></defs><path className="arrowDown_a" d="M0,0H20V20H0Z" /><path className="arrowDown_b" d="M16.59,8.59,12,13.17,7.41,8.59,6,10l6,6,6-6Z" transform="translate(-2 -2.071)" /></svg>
                    </div>
                    <ul className="navigation-lists__lists">
                      <li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/sukienki/jesien#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Modne sukienki na jesień">Modne sukienki na jesień</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/botki/czarne#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Czarne botki">Czarne botki</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://avanti24.pl/trendy-mody#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Trendy mody">Trendy mody</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/czapki/zima#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Czapki na zimę">Czapki na zimę</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/golfy/damskie#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Golfy damskie">Golfy damskie</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://avanti24.pl/hot#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Hot trendy">Hot trendy</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://avanti24.pl/newsy/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Moda news">Moda news</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/kozaki/bezowy/damskie#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Beżowe kozaki">Beżowe kozaki</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/damskie?kategorie=cygaretki#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Modne cygaretki">Modne cygaretki</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/damskie?kategorie=sukienki-male-czarne#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Czarne sukienki">Czarne sukienki</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/kalosze/damskie#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Kalosze damskie">Kalosze damskie</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/kamizelki/damskie/futro#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Kamizelki futrzane">Kamizelki futrzane</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/sukienki/slub-i-wesele#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Sukienki na wesele">Sukienki na wesele</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/spodnice/mini#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Spódnice mini">Spódnice mini</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/zakiety#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Modne marynarki">Modne marynarki</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/torby#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Torby na jesień">Torby na jesień</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/kardigany#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Stylowe kardigany">Stylowe kardigany</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/zegarki/damskie#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Zegarki damskie">Zegarki damskie</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/sztyblety/damskie#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Wygodne sztyblety damskie">Wygodne sztyblety damskie</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zakupy.avanti24.pl/kozaki/damskie#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Modne kozaki damskie">Modne kozaki damskie</a>
                      </li>
                    </ul>
                  </div><div className="navigation-lists__group">
                    <div className="navigation-lists__smalltitle">
                      <div className="navigation-lists__smalltitleName">Lokale</div>
                      <svg className="navigation-lists__smalltitleSVG" xmlns="http://www.w3.org/2000/svg" width={20} height={20} viewBox="0 0 20 20"><defs><style dangerouslySetInnerHTML={{__html: ".arrowDown_a{fill:none;}.arrowDown_b{fill:#444;}" }} /></defs><path className="arrowDown_a" d="M0,0H20V20H0Z" /><path className="arrowDown_b" d="M16.59,8.59,12,13.17,7.41,8.59,6,10l6,6,6-6Z" transform="translate(-2 -2.071)" /></svg>
                    </div>
                    <ul className="navigation-lists__lists">
                      <li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://bialystok.wyborcza.pl/bialystok/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Białystok">Białystok</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://bielskobiala.wyborcza.pl/bielskobiala/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Bielsko-Biała">Bielsko-Biała</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://bydgoszcz.wyborcza.pl/bydgoszcz/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Bydgoszcz">Bydgoszcz</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://czestochowa.wyborcza.pl/czestochowa/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Częstochowa">Częstochowa</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://gorzow.wyborcza.pl/gorzow/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Gorzów Wlkp.">Gorzów Wlkp.</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://katowice.wyborcza.pl/katowice/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Katowice">Katowice</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://kielce.wyborcza.pl/kielce/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Kielce">Kielce</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://krakow.wyborcza.pl/krakow/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Kraków">Kraków</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://lublin.wyborcza.pl/lublin/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Lublin">Lublin</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://lodz.wyborcza.pl/lodz/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Łódź">Łódź</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://poznan.wyborcza.pl/poznan/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Poznań">Poznań</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://plock.wyborcza.pl/plock/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Płock">Płock</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://opole.wyborcza.pl/opole/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Opole">Opole</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://olsztyn.wyborcza.pl/olsztyn/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Olsztyn">Olsztyn</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://radom.wyborcza.pl/radom/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Radom">Radom</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://rzeszow.wyborcza.pl/rzeszow/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Rzeszów">Rzeszów</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://szczecin.wyborcza.pl/szczecin/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Szczecin">Szczecin</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://torun.wyborcza.pl/torun/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Toruń">Toruń</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://trojmiasto.wyborcza.pl/trojmiasto/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Trójmiasto">Trójmiasto</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://warszawa.wyborcza.pl/warszawa/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Warszawa">Warszawa</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://wroclaw.wyborcza.pl/wroclaw/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Wrocław">Wrocław</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zielonagora.wyborcza.pl/zielonagora/0,0.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Zielona Góra">Zielona Góra</a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="navigation-lists__row navigation-lists__row--popular">
                  <span className="navigation-lists__smalltitle">POPULARNE TEMATY</span>
                  <div className="navigation-lists__column">
                    <ul className="navigation-lists__lists">
                      <li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/next/7,151003,25948441,1000-zl-bon-turystyczny-dla-kogo-od-kiedy-jakie-sa-zasady.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Bon turystyczny">Bon turystyczny</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/internet/7,104530,25949081,5g-w-polsce-co-daje-siec-5g-jakie-telefony-ja-obsluguja.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Internet 5G">Internet 5G</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/next/7,151243,24505452,7-sposobow-aby-poprawic-jakosc-obrazu-w-telewizorze-nie-tylko.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Jak poprawić obraz w TV">Jak poprawić obraz w TV</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/next/7,151003,26240358,urlop-wychowawczy-2020-kalkulator-urlopu-wychowawczego.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Kalkulator urlopu wychowawczego">Kalkulator urlopu wychowawczego</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/next/7,151003,26042673,pracownicze-plany-kapitalowe-ppk-zasady-czy-warto-co-z-pieniedzmi.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Pracownicze Plany Kapitałowe - co to jest?">Pracownicze Plany Kapitałowe - co to jest?</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/next/7,151003,26467257,zasilek-opiekunczy-2021-ile-wynosi-komu-i-kiedy-przysluguje.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Zasiłek opiekuńczy 2021">Zasiłek opiekuńczy 2021</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/next/7,151003,26304862,placa-minimalna-2021-2800-zlotych-brutto-ile-to-netto-na.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Płaca minimalna na rękę">Płaca minimalna na rękę</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/next/7,151003,26647617,oplata-mocowa-2021-rachunki-za-prad-w-gore-znamy-stawki-nowej.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Opłata mocowa 2021">Opłata mocowa 2021</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/next/7,151003,26824614,wyzsze-emerytury-dzieki-covid-19.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Wyższe emerytury">Wyższe emerytury</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/next/7,151003,26648727,ulga-abolicyjna-okrojona-pracujacy-za-granica-w-2021-roku-zarobia.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Ulga abolicyjna 2021">Ulga abolicyjna 2021</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://next.gazeta.pl/next/7,151003,26913849,podatek-od-wygranej-ile-wynosi-i-kto-musi-go-zaplacic-lotto.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Ile wynosi podatek od wygranej?">Ile wynosi podatek od wygranej?</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://kobieta.gazeta.pl/kobieta/7,107880,25856641,ons-co-to-takiego-tlumaczymy-tajemnicze-skroty-z-aplikacji.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Co to jest ONS?">Co to jest ONS?</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://kobieta.gazeta.pl/kobieta/7,107880,26362293,co-to-znaczy-fwb-sprawdz-ten-skrot-i-zdecyduj-czy-ci-pasuje.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Co to jest FWB?">Co to jest FWB?</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zdrowie.gazeta.pl/grzyby#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Grzyby">Grzyby</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://zdrowie.gazeta.pl/grzyby-jadalne#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Grzyby jadalne">Grzyby jadalne</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://podroze.gazeta.pl/podroze/7,114158,27484016,doba-hotelowa-co-to-jest-i-kiedy-sie-konczy-jak-przedluzyc.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Co to jest doba hotelowa?">Co to jest doba hotelowa?</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://podroze.gazeta.pl/podroze/7,114158,27449580,zwrot-biletu-pkp-jak-go-dokonac-krok-po-kroku.html#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Jak zwrócić bilet PKP?">Jak zwrócić bilet PKP?</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://wiadomosci.gazeta.pl/wierszyki#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Wierszyki">Wierszyki</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://wiadomosci.gazeta.pl/zyczenia#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Życzenia">Życzenia</a>
                      </li><li className="navigation-lists__list-item">
                        <a className="navigation-lists__link" href="https://wiadomosci.gazeta.pl/rymowanki#e=CapMoreSeo" id="LinkArea:CapMoreSeo" title="Rymowanki">Rymowanki</a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="navigation-lists__row navigation-lists__fold">
                  <span className="navigation-lists__fold_button">ZWIŃ</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width={20} height={20} viewBox="0 0 20 20"><defs><style dangerouslySetInnerHTML={{__html: ".arrow_up-a{fill:none;}.arrow_up-b{fill:#444;}" }} /></defs><path className="arrow_up-a" d="M0,0H20V20H0Z" /><path className="arrow_up-b" d="M12,8,6,14l1.41,1.41L12,10.83l4.59,4.58L18,14Z" transform="translate(-2 -1.929)" /></svg>
                </div>
              </nav>
            </div>{/* UZREditor */}{/* htmEOF */}</header>
          {/*2080594, position: hat, name: hat, MeasurableViewWrapper : PortalModuleView : DefaultModuleView : InheritingModuleInternalResourceView : /tpl/prod/modules/hat/desktop/hat.jsp : /tpl/prod/modules/hat/desktop/hat.jsp, emptyBean*/}
          <div className="navBox">
            <div className="serviceLogo ">
              <div className="serviceLogo__logoGroupElements">
                <a className="serviceLogo__logo" href="https://next.gazeta.pl/next/0,0.html#e=LogoS" id="LinkArea:LogoS">Next</a>
              </div>
              <div className="serviceLogo__button" />
            </div>{/* UZREditor */}{/* htmEOF */}
            {/*27272293, position: serviceLogo, name: serviceLogo, MeasurableViewWrapper : PortalModuleView : DefaultModuleView : InheritingModuleInternalResourceView : /htm/27272/j27272293.htm : /htm/27272/j27272293.htm, null*/}
            {/* menubar2021 v0.26 showNavigation:true, isMobile:false */}
            <div className="nav__overlay">
              <ul className="nav__mainMenu">
                <li className="nav__item">{/* level 1.1 */}
                  <a href="https://next.gazeta.pl/polityka#e=NavLink" id="LinkArea:NavLink" className="nav__itemName">Polityka</a>
                  <div className="nav__overlayList">
                    <div className="nav__list">
                      {/* level 2.1 */}
                      <a href="https://next.gazeta.pl/tarcza-antykryzysowa#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Tarcza antykryzysowa</a>
                      {/* level 2.2 */}
                      <a href="https://next.gazeta.pl/unia-europejska#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Unia Europejska</a>
                      {/* level 2.3 */}
                      <a href="https://next.gazeta.pl/ministerstwo-finansow#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Ministerstwo Finansów</a>
                      {/* level 2.4 */}
                      <a href="https://next.gazeta.pl/nbp#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        NBP</a>
                      {/* level 2.5 */}
                      <a href="https://next.gazeta.pl/inflacja#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Inflacja</a>
                      {/* level 2.6 */}
                      <a href="https://next.gazeta.pl/pkb#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem nav__last">
                        PKB</a>
                    </div>
                  </div>
                </li>
                <li className="nav__item">{/* level 1.2 */}
                  <a href="https://next.gazeta.pl/polska#e=NavLink" id="LinkArea:NavLink" className="nav__itemName">Pieniądze</a>
                  <div className="nav__overlayList">
                    <div className="nav__list">
                      {/* level 2.1 */}
                      <a href="https://next.gazeta.pl/emerytury#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Emerytury</a>
                      {/* level 2.2 */}
                      <a href="https://next.gazeta.pl/praca#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Praca</a>
                      {/* level 2.3 */}
                      <a href="https://next.gazeta.pl/bezrobocie#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Bezrobocie</a>
                      {/* level 2.4 */}
                      <a href="https://next.gazeta.pl/podatki#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Podatki</a>
                      {/* level 2.5 */}
                      <a href="https://next.gazeta.pl/zarobki#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Zarobki</a>
                      {/* level 2.6 */}
                      <a href="https://next.gazeta.pl/niedziele-handlowe#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Niedziele handlowe</a>
                      {/* level 2.7 */}
                      <a href="https://next.gazeta.pl/500-plus#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        500 plus</a>
                      {/* level 2.8 */}
                      <a href="https://next.gazeta.pl/zus#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        ZUS</a>
                      {/* level 2.9 */}
                      <a href="https://next.gazeta.pl/pit#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        PIT</a>
                      {/* level 2.10 */}
                      <a href="https://next.gazeta.pl/uokik#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        UOKiK</a>
                      {/* level 2.11 */}
                      <a href="https://next.gazeta.pl/certyfikat-covidowy#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem nav__last">
                        Certyfikat covidowy</a>
                    </div>
                  </div>
                </li>
                <li className="nav__item">{/* level 1.3 */}
                  <a href="https://next.gazeta.pl/next/0,150859.html#e=NavLink" id="LinkArea:NavLink" className="nav__itemName">Biznes</a>
                  <div className="nav__overlayList">
                    <div className="nav__list">
                      {/* level 2.1 */}
                      <a href="https://next.gazeta.pl/gielda#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Giełda</a>
                      {/* level 2.2 */}
                      <a href="https://next.gazeta.pl/nieruchomosci#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Nieruchomości</a>
                      {/* level 2.3 */}
                      <a href="https://next.gazeta.pl/przedsiebiorcy#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Przedsiębiorcy</a>
                      <div className="nav__itemBox">{/* level 2.4 */}
                        <a href="https://next.gazeta.pl/pieniadze#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                          Pieniądze</a>
                        {/* level 3.1 */}
                        <a href="https://next.gazeta.pl/kursy-walut#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                          Kursy Walut</a>
                      </div>{/* nav__itemBox */}{/* level 3.2 */}
                      <a href="https://next.gazeta.pl/kryptowaluty#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        Kryptowaluty</a>
                      {/* level 3.3 */}
                      <a href="https://next.gazeta.pl/bitcoin#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        Bitcoin</a>
                      <div className="nav__itemBox">{/* level 2.5 */}
                        <a href="https://next.gazeta.pl/surowce#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                          Surowce</a>
                        {/* level 3.1 */}
                        <a href="https://next.gazeta.pl/zloto#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                          Złoto</a>
                      </div>{/* nav__itemBox */}{/* level 3.2 */}
                      <a href="https://next.gazeta.pl/srebro#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        Srebro</a>
                      {/* level 3.3 */}
                      <a href="https://next.gazeta.pl/ropa#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        Ropa</a>
                      {/* level 3.4 */}
                      <a href="https://next.gazeta.pl/miedz#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        Miedź</a>
                      <div className="nav__itemBox">{/* level 2.6 */}
                        <a href="https://next.gazeta.pl/ceny#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                          Ceny</a>
                        {/* level 3.1 */}
                        <a href="https://next.gazeta.pl/ceny-paliw#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                          Ceny paliw</a>
                      </div>{/* nav__itemBox */}{/* level 3.2 */}
                      <a href="https://next.gazeta.pl/ceny-mieszkan#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        Ceny mieszkań</a>
                      {/* level 3.3 */}
                      <a href="https://next.gazeta.pl/ceny-pradu#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        Ceny prądu</a>
                      {/* level 3.4 */}
                      <a href="https://next.gazeta.pl/ceny-zywnosci#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem nav__last">
                        Ceny żywności</a>
                    </div>
                  </div>
                </li>
                <li className="nav__item">{/* level 1.4 */}
                  <a href="https://next.gazeta.pl/next/0,150860.html#e=NavLink" id="LinkArea:NavLink" className="nav__itemName">Technologie</a>
                  <div className="nav__overlayList">
                    <div className="nav__list">
                      {/* level 2.1 */}
                      <a href="https://next.gazeta.pl/tesla#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Tesla</a>
                      {/* level 2.2 */}
                      <a href="https://next.gazeta.pl/apple#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Apple</a>
                      {/* level 2.3 */}
                      <a href="https://next.gazeta.pl/microsoft#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Microsoft</a>
                      {/* level 2.4 */}
                      <a href="https://next.gazeta.pl/google#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Google</a>
                      {/* level 2.5 */}
                      <a href="https://next.gazeta.pl/facebook#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Facebook</a>
                      {/* level 2.6 */}
                      <a href="https://next.gazeta.pl/cd-projekt#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        CD Projekt</a>
                      {/* level 2.7 */}
                      <a href="https://next.gazeta.pl/nasa#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        NASA</a>
                      {/* level 2.8 */}
                      <a href="https://next.gazeta.pl/aplikacje#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Aplikacje</a>
                      {/* level 2.9 */}
                      <a href="https://next.gazeta.pl/sztuczna-inteligencja#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Sztuczna inteligencja</a>
                      {/* level 2.10 */}
                      <a href="https://next.gazeta.pl/gry-komputerowe#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Gry komputerowe</a>
                      <div className="nav__itemBox">{/* level 2.11 */}
                        <a href="https://next.gazeta.pl/sprzet#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                          Sprzęt</a>
                        {/* level 3.1 */}
                        <a href="https://next.gazeta.pl/laptopy#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                          Laptopy</a>
                      </div>{/* nav__itemBox */}{/* level 3.2 */}
                      <a href="https://next.gazeta.pl/telewizory#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        Telewizory</a>
                      {/* level 3.3 */}
                      <a href="https://next.gazeta.pl/smartfony#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        Smartfony</a>
                      {/* level 3.4 */}
                      <a href="https://next.gazeta.pl/konsole#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        Konsole</a>
                      {/* level 3.5 */}
                      <a href="https://next.gazeta.pl/agd#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem ">
                        AGD</a>
                      {/* level 3.6 */}
                      <a href="https://next.gazeta.pl/rtv#e=NavLink" id="LinkArea:NavLink" className="nav__thirdLevelItem nav__last">
                        RTV</a>
                    </div>
                  </div>
                </li>
                <li className="nav__item">{/* level 1.5 */}
                  <a href="https://next.gazeta.pl/next/0,172690.html#e=NavLink" id="LinkArea:NavLink" className="nav__itemName">Nauka</a>
                  <div className="nav__overlayList">
                    <div className="nav__list">
                      {/* level 2.1 */}
                      <a href="https://next.gazeta.pl/kosmos#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Kosmos</a>
                      {/* level 2.2 */}
                      <a href="https://next.gazeta.pl/medycyna#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Medycyna</a>
                      {/* level 2.3 */}
                      <a href="https://next.gazeta.pl/ciekawostki#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem nav__last">
                        Ciekawostki</a>
                    </div>
                  </div>
                </li>
                <li className="nav__item">{/* level 1.6 */}
                  <a href="https://next.gazeta.pl/next/0,172392.html#e=NavLink" id="LinkArea:NavLink" className="nav__itemName">Środowisko</a>
                  <div className="nav__overlayList">
                    <div className="nav__list">
                      {/* level 2.1 */}
                      <a href="https://next.gazeta.pl/next/0,179892.html#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem ">
                        Klimat z bliska</a>
                      {/* level 2.2 */}
                      <a href="https://next.gazeta.pl/glosem-ekspertow#e=NavLink" id="LinkArea:NavLink" className="nav__secondLevelItem nav__last">
                        Głosem ekspertów</a>
                    </div>
                  </div>
                </li>
                <li className="nav__item">{/* level 1.7 */}
                  <a href="https://next.gazeta.pl/next/0,173953.html#e=NavLink" id="LinkArea:NavLink" className="nav__itemName">Koronawirus</a>
                </li>
                <li className="nav__dropDownButton">
                  <div className="nav__dropDownOverlay">
                    <div className="nav__dropDownList">
                      {/* beak_level_1.1 */}
                      <div className="nav__itemBox"><a href="https://next.gazeta.pl/porady#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__firstLevelItem ">Porady</a>
                        {/* beak_level_2.1 */}
                        <a href="https://next.gazeta.pl/next/7,151003,26681058,placa-minimalna-2021-ile-wynosi-najnizsza-krajowa-ile-mozna.html#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                          Płaca minimalna 2021</a>
                      </div>{/* nav__itemBox */}{/* beak_level_2.2 */}
                      <a href="https://next.gazeta.pl/next/7,151003,26681058,placa-minimalna-2021-ile-wynosi-najnizsza-krajowa-ile-mozna.html#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Abonament RTV 2021</a>
                      {/* beak_level_2.3 */}
                      <a href="https://next.gazeta.pl/next/7,151003,26596527,500-plus-w-2021-roku-jakie-zmiany-w-swiadczeniu-rodzice-musza.html#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        500 plus 2021</a>
                      {/* beak_level_2.4 */}
                      <a href="https://next.gazeta.pl/next/7,151003,26575831,waloryzacja-rent-i-emerytur-w-2021-roku-od-marca-podwyzka.html#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Waloryzacja rent i emerytur 2021</a>
                      {/* beak_level_2.5 */}
                      <a href="https://next.gazeta.pl/next/7,151003,26791129,jak-rozliczyc-pit-2021-15-lutego-ruszyla-usluga-twoj-e-pit.html#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Jak rozliczyć pit 2021</a>
                      {/* beak_level_2.6 */}
                      <a href="https://next.gazeta.pl/next/7,151003,26026872,pit-2021-zwrot-podatku-jak-sprawdzic-kiedy-go-otrzymamy.html#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Zwrot podatku 2021</a>
                      {/* beak_level_2.7 */}
                      <a href="https://next.gazeta.pl/next/7,151003,26581384,dni-wolne-od-pracy-w-2021-roku-kiedy-warto-wziac-urlop.html#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Dni wolne od pracy 2021</a>
                      {/* beak_level_2.8 */}
                      <a href="https://next.gazeta.pl/next/7,173953,25834002,otwieranie-paczkomatu-za-posrednictwem-aplikacji-jak-odebrac.html#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem nav__lastItem">
                        Otwieranie paczkomatu</a>
                      {/* beak_level_1.2 */}
                      <div className="nav__itemBox"><a href="https://next.gazeta.pl/najbogatsi#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__firstLevelItem ">Najbogatsi</a>
                        {/* beak_level_2.1 */}
                        <a href="https://next.gazeta.pl/jeff-bezos#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                          Jeff Bezos</a>
                      </div>{/* nav__itemBox */}{/* beak_level_2.2 */}
                      <a href="https://next.gazeta.pl/elon-musk#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Elon Musk</a>
                      {/* beak_level_2.3 */}
                      <a href="https://next.gazeta.pl/bill-gates#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Bill Gates</a>
                      {/* beak_level_2.4 */}
                      <a href="https://next.gazeta.pl/mark-zuckerberg#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Mark Zuckerberg</a>
                      {/* beak_level_2.5 */}
                      <a href="https://next.gazeta.pl/donald-trump#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem nav__lastItem">
                        Donald Trump</a>
                      {/* beak_level_1.3 */}
                      <div className="nav__itemBox"><a href="https://next.gazeta.pl/marki#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__firstLevelItem ">Marki</a>
                        {/* beak_level_2.1 */}
                        <a href="https://next.gazeta.pl/amazon#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                          Amazon</a>
                      </div>{/* nav__itemBox */}{/* beak_level_2.2 */}
                      <a href="https://next.gazeta.pl/instagram#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Instagram</a>
                      {/* beak_level_2.3 */}
                      <a href="https://next.gazeta.pl/lot#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        LOT</a>
                      {/* beak_level_2.4 */}
                      <a href="https://next.gazeta.pl/youtube#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        YouTube</a>
                      {/* beak_level_2.5 */}
                      <a href="https://next.gazeta.pl/spacex#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        SpaceX</a>
                      {/* beak_level_2.6 */}
                      <a href="https://next.gazeta.pl/ing#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        ING</a>
                      {/* beak_level_2.7 */}
                      <a href="https://next.gazeta.pl/xiaomi#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Xiaomi</a>
                      {/* beak_level_2.8 */}
                      <a href="https://next.gazeta.pl/samsung#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Samsung</a>
                      {/* beak_level_2.9 */}
                      <a href="https://next.gazeta.pl/lidl#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Lidl</a>
                      {/* beak_level_2.10 */}
                      <a href="https://next.gazeta.pl/spotify#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Spotify</a>
                      {/* beak_level_2.11 */}
                      <a href="https://next.gazeta.pl/sony#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Sony</a>
                      {/* beak_level_2.12 */}
                      <a href="https://next.gazeta.pl/instagram#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Instagram</a>
                      {/* beak_level_2.13 */}
                      <a href="https://next.gazeta.pl/orlen#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Orlen</a>
                      {/* beak_level_2.14 */}
                      <a href="https://next.gazeta.pl/mbank#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        mBank</a>
                      {/* beak_level_2.15 */}
                      <a href="https://next.gazeta.pl/pge#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        PGE</a>
                      {/* beak_level_2.16 */}
                      <a href="https://next.gazeta.pl/biedronka#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Biedronka</a>
                      {/* beak_level_2.17 */}
                      <a href="https://next.gazeta.pl/dino#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        Dino</a>
                      {/* beak_level_2.18 */}
                      <a href="https://next.gazeta.pl/pkp#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem ">
                        PKP</a>
                      {/* beak_level_2.19 */}
                      <a href="https://next.gazeta.pl/rossmann#e=NavMoreSeo" id="LinkArea:NavMoreSeo" className="nav__secondLevelItem nav__lastItem">
                        Rossmann</a>
                    </div>
                  </div>
                </li>
              </ul>
            </div>{/* end menu2020 desk */}
            {/*26380542, position: menubar, name: menubar, MeasurableViewWrapper : PortalModuleView : DefaultModuleView : InheritingModuleInternalResourceView : /tpl/prod/modules/navigation/menubar2021.jsp : /tpl/prod/modules/navigation/menubar2021.jsp, menubarController*/}
          </div>
          <div className="notificationBox" />
          <div className="c2sPlayer playerHiddenTop" id="onn-player__container">
            <div className="c2sPlayer__wrapper">
              <button className="c2sPlayer__wrapper__audioBtn" id="c2s_audioBtn" />
              <div className="c2sPlayer__wrapper__volume">
                <button className="c2sPlayer__wrapper__volume__volumeBtn" id="c2s_volumeBtn" />
                <input defaultValue={80} min={0} max={100} className="c2sPlayer__wrapper__volume__slider onn-player__slider" type="range" id="c2s_volumeSlider" />
              </div>
              <div className="c2sPlayer__wrapper__audioSlider">
                <input defaultValue={0} className="c2sPlayer__wrapper__audioSlider__slider" type="range" id="c2s_audioSlider" max={118} />
                <div className="c2sPlayer__wrapper__audioSlider__timestamp">
                  <div className="c2sPlayer__wrapper__audioSlider__ad hidden" />
                  <div>
                    <span id="c2s_currentTime">00:00</span> /
                    <span id="c2s_endTime">01:58</span>
                  </div>
                </div>
              </div>
              <button className="c2sPlayer__wrapper__closeBtn" id="c2s_closeBtn" />
              <div id="onn-player__player" style={{width: '1px', height: '1px'}}><div id="EXSa7f3d4fafb8a0cac46ab108232cc8ba11" className="checkvis onnetworkplayercontainer desktop wid8610 country0 podcast0 smin0 closer closer1 mmpl0 nonevisible" style={{paddingBottom: 'calc( 56.25% - 1px )'}} data-closerdelay={0}><div id="dffEXSa7f3d4fafb8a0cac46ab108232cc8ba11" className="checkvisc normplayer alwplayer desktop" style={{aspectRatio: '16 / 9'}}><iframe title="Onnetwork video player" id="ffEXSa7f3d4fafb8a0cac46ab108232cc8ba11" className="checkvisc onnetworkframe desktop" style={{aspectRatio: '16 / 9'}} scrolling="no" allowFullScreen allow="autoplay; fullscreen" src="https://video.onnetwork.tv/frame86.php?mid=NDc0NjI5LDE2eDksMCwyMCwwLDg2MTAsMSwwLDEsMjAsNiwwLDAsMCwxLDEsMCwwLDAsMCwwLDAsMSwwLDAsMCwwLC0xOy0xOzIwOzIwLDAsMCww&preview=0&iid=1633069064733&e=1&ap=0&isCpl=1&id=ffEXSa7f3d4fafb8a0cac46ab108232cc8ba11&t_page=next_7_151003_27635468_wielka_brytania_zmiany_w_zasadach_wjazdu_od_1_pazdziernika_html&wtop=https%3A%2F%2Fnext.gazeta.pl%2Fnext%2F7%2C151003%2C27635468%2Cwielka-brytania-zmiany-w-zasadach-wjazdu-od-1-pazdziernika.html&apop=0&vpop=0&apopa=0&vpopa=0&cId=onn-player__player&AGra=1&vasturl=%2F%2Fpubads.g.doubleclick.net%2Fgampad%2Fads%3Fsz%3D1x1%26iu%3D%2F75224259%2FAGORA-IN%2FNext%2F090-PREROLL%26cust_params%3Dpos%253D090-PREROLL%2526dx%253D151003%2526jsp%253D23%2526dir%253Dnext%2526kw%253D%5Bbrandsafe%5D%252C%5Bplayer_type%5D%252Caudio%2526dystrybutor%253D%5Bdistributor_id%5D%2526passback_id%253D%5Bpassback_id%5D%2526domena%253D%5Badview_hostname%5D%2526cb%253D%5Bcb%5D%2526article_id%253D27635468%26url%3D%5Blocationhref%5D%26description_url%3D%5Blocationhref%5D%26impl%3Ds%26gdfp_req%3D1%26env%3Dinstream%26output%3Dvast%26ad_type%3Daudio%26unviewed_position_start%3D1%26correlator%3D%5Btimestamp%5D" /></div></div></div>
            </div>
          </div></div>
      );
    }
  };