export default function NewsBox({ ...props }) {

    return (
<div className="newsBox lazy_load">
        <div className="newsBox__header" style={{left: '0px'}}>
          <div className="newsBox__tab newsBox--activeTab" data-tab="tab1">POPULARNE</div>
          <div className="newsBox__tab" data-tab="tab2">NAJNOWSZE</div>
        </div>
        <div className="newsBox__content" style={{height: '532px', transform: 'translateX(0px)'}}>
          <div className="newsBox__contentElement newsBox__popularList newsBox__photoVersion">
            <ul>
              <li className="newsBox__item">
                <a className="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27649758,facebook-juz-dziala-jest-komunikat-firmy-o-przyczynach-bledna.html#do_w=48&do_v=60&do_st=RS&do_sid=417&do_a=417&e=PSzPopImg1" title="Facebook działa. Koniec największej awarii w historii firmy. Jest komunikat o przyczynach" data-bd-viewability={1} data-bd-viewability-id="newsBoxPopularList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27649758,facebook-juz-dziala-jest-komunikat-firmy-o-przyczynach-bledna.html#do_w=48&do_v=60&do_st=RS&do_sid=417&do_a=417&e=PSzPopImg1">
                  <span className="newsBox__itemPhotoBox">
                    <noscript>
                      &lt;img class="newsBox__itemPhoto" src="https://bi.im-g.pl/im/df/5e/1a/z27649759F,Facebook.jpg" alt="Facebook działa. Koniec największej awarii w historii firmy. Jest komunikat o przyczynach" /&gt;
                    </noscript>
                    <img className="newsBox__itemPhoto loaded" src="https://bi.im-g.pl/im/df/5e/1a/z27649759F,Facebook.jpg" data-src="https://bi.im-g.pl/im/df/5e/1a/z27649759F,Facebook.jpg" alt="Facebook działa. Koniec największej awarii w historii firmy. Jest komunikat o przyczynach" />
                  </span>
                  <span className="newsBox__itemTitle">Facebook działa. Koniec największej awarii w historii firmy. Jest komunikat o przyczynach</span>
                </a>
              </li>
              <li className="newsBox__item">
                <a className="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27635633,skrajne-ubostwo-wyeliminowalibysmy-za-ulamek-kwoty-ktora-wydajemy.html#do_w=48&do_v=60&do_st=RS&do_sid=417&do_a=417&e=PSzPopImg2" title="&quot;Skrajne ubóstwo wyeliminowalibyśmy za ułamek kwoty, którą wydajemy na 500 plus. Ale to niewykonalne&quot;" data-bd-viewability={1} data-bd-viewability-id="newsBoxPopularList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27635633,skrajne-ubostwo-wyeliminowalibysmy-za-ulamek-kwoty-ktora-wydajemy.html#do_w=48&do_v=60&do_st=RS&do_sid=417&do_a=417&e=PSzPopImg2">
                  <span className="newsBox__itemPhotoBox">
                    <noscript>
                      &lt;img class="newsBox__itemPhoto" src="https://bi.im-g.pl/im/69/5b/1a/z27636585F,DLOLO.jpg" alt="&amp;#034;Skrajne ubóstwo wyeliminowalibyśmy za ułamek kwoty, którą wydajemy na 500 plus. Ale to niewykonalne&amp;#034;" /&gt;
                    </noscript>
                    <img className="newsBox__itemPhoto loaded" src="https://bi.im-g.pl/im/69/5b/1a/z27636585F,DLOLO.jpg" data-src="https://bi.im-g.pl/im/69/5b/1a/z27636585F,DLOLO.jpg" alt="&quot;Skrajne ubóstwo wyeliminowalibyśmy za ułamek kwoty, którą wydajemy na 500 plus. Ale to niewykonalne&quot;" />
                  </span>
                  <span className="newsBox__itemTitle">"Skrajne ubóstwo wyeliminowalibyśmy za ułamek kwoty, którą wydajemy na 500 plus. Ale to niewykonalne"</span>
                </a>
              </li>
              <li className="newsBox__item">
                <a className="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27647177,grozna-sytuacja-na-otwarciu-drogi-s7-szalenie-niebezpieczne.html#do_w=48&do_v=60&do_st=RS&do_sid=417&do_a=417&e=PSzPopImg3" title="Groźna sytuacja na otwarciu drogi S7? &quot;Szalenie niebezpieczne&quot;, &quot;Tupolewizm wiecznie żywy&quot;" data-bd-viewability={1} data-bd-viewability-id="newsBoxPopularList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27647177,grozna-sytuacja-na-otwarciu-drogi-s7-szalenie-niebezpieczne.html#do_w=48&do_v=60&do_st=RS&do_sid=417&do_a=417&e=PSzPopImg3">
                  <span className="newsBox__itemPhotoBox">
                    <noscript>
                      &lt;img class="newsBox__itemPhoto" src="https://bi.im-g.pl/im/9c/5d/1a/z27647388F,Otwarcie-fragmentu-drogi-ekspresowej-S7.jpg" alt="Groźna sytuacja na otwarciu drogi S7? &amp;#034;Szalenie niebezpieczne&amp;#034;, &amp;#034;Tupolewizm wiecznie żywy&amp;#034;" /&gt;
                    </noscript>
                    <img className="newsBox__itemPhoto loaded" src="https://bi.im-g.pl/im/9c/5d/1a/z27647388F,Otwarcie-fragmentu-drogi-ekspresowej-S7.jpg" data-src="https://bi.im-g.pl/im/9c/5d/1a/z27647388F,Otwarcie-fragmentu-drogi-ekspresowej-S7.jpg" alt="Groźna sytuacja na otwarciu drogi S7? &quot;Szalenie niebezpieczne&quot;, &quot;Tupolewizm wiecznie żywy&quot;" />
                  </span>
                  <span className="newsBox__itemTitle">Groźna sytuacja na otwarciu drogi S7? "Szalenie niebezpieczne", "Tupolewizm wiecznie żywy"</span>
                </a>
              </li>
              <li className="newsBox__item">
                <a className="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151243,27650216,facebook-nie-mogl-naprawic-facebooka-bo-facebook-trzyma-wszystko.html#do_w=48&do_v=60&do_st=RS&do_sid=417&do_a=417&e=PSzPopImg4" title="Facebook nie mógł naprawić Facebooka, bo Facebook trzyma wszystko na Facebooku" data-bd-viewability={1} data-bd-viewability-id="newsBoxPopularList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151243,27650216,facebook-nie-mogl-naprawic-facebooka-bo-facebook-trzyma-wszystko.html#do_w=48&do_v=60&do_st=RS&do_sid=417&do_a=417&e=PSzPopImg4">
                  <span className="newsBox__itemPhotoBox">
                    <noscript>
                      &lt;img class="newsBox__itemPhoto" src="https://bi.im-g.pl/im/eb/6f/19/z26671339F,Mark-Zuckerberg.jpg" alt="Facebook nie mógł naprawić Facebooka, bo Facebook trzyma wszystko na Facebooku" /&gt;
                    </noscript>
                    <img className="newsBox__itemPhoto loaded" src="https://bi.im-g.pl/im/eb/6f/19/z26671339F,Mark-Zuckerberg.jpg" data-src="https://bi.im-g.pl/im/eb/6f/19/z26671339F,Mark-Zuckerberg.jpg" alt="Facebook nie mógł naprawić Facebooka, bo Facebook trzyma wszystko na Facebooku" />
                  </span>
                  <span className="newsBox__itemTitle">Facebook nie mógł naprawić Facebooka, bo Facebook trzyma wszystko na Facebooku</span>
                </a>
              </li>
              <li className="newsBox__item">
                <a className="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27647040,polski-lad-emerytury-wzrosna-nawet-o-187-zl-ale-sa-tez-tacy.html#do_w=48&do_v=60&do_st=RS&do_sid=417&do_a=417&e=PSzPopImg5" title="Polski Ład. Emerytury wzrosną nawet o 187 zł. Ale są też tacy, którym świadczenie spadnie [TABELA]" data-bd-viewability={1} data-bd-viewability-id="newsBoxPopularList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27647040,polski-lad-emerytury-wzrosna-nawet-o-187-zl-ale-sa-tez-tacy.html#do_w=48&do_v=60&do_st=RS&do_sid=417&do_a=417&e=PSzPopImg5">
                  <span className="newsBox__itemPhotoBox">
                    <noscript>
                      &lt;img class="newsBox__itemPhoto" src="https://bi.im-g.pl/im/37/5b/1a/z27638839F,Emerytura--zdjecie-ilustracyjne-.jpg" alt="Polski Ład. Emerytury wzrosną nawet o 187 zł. Ale są też tacy, którym świadczenie spadnie [TABELA]" /&gt;
                    </noscript>
                    <img className="newsBox__itemPhoto loaded" src="https://bi.im-g.pl/im/37/5b/1a/z27638839F,Emerytura--zdjecie-ilustracyjne-.jpg" data-src="https://bi.im-g.pl/im/37/5b/1a/z27638839F,Emerytura--zdjecie-ilustracyjne-.jpg" alt="Polski Ład. Emerytury wzrosną nawet o 187 zł. Ale są też tacy, którym świadczenie spadnie [TABELA]" />
                  </span>
                  <span className="newsBox__itemTitle">Polski Ład. Emerytury wzrosną nawet o 187 zł. Ale są też tacy, którym świadczenie spadnie [TABELA]</span>
                </a>
              </li>
            </ul>
          </div>
          <div className="newsBox__contentElement newsBox__newestList">
            <ul>
              <li className="newsBox__item">
                <time className="newsBox__itemTime" dateTime="2021-10-05">14:50</time>
                <a className="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27651758,knf-ostrzega-oszusci-stworzyli-falszywa-strone-banku-credit.html#do_w=48&do_v=60&do_st=RS&do_sid=305&do_a=305&e=PSzLatLink1" title="KNF ostrzega. Oszuści stworzyli fałszywą stronę banku Credit Agricole, aby wyłudzać dane" data-bd-viewability={1} data-bd-viewability-id="newsBoxNewestList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27651758,knf-ostrzega-oszusci-stworzyli-falszywa-strone-banku-credit.html#do_w=48&do_v=60&do_st=RS&do_sid=305&do_a=305&e=PSzLatLink1">
                  <span className="newsBox__itemTitle">KNF ostrzega. Oszuści stworzyli fałszywą stronę banku Credit Agricole, aby wyłudzać dane</span>
                </a>
              </li>
              <li className="newsBox__item">
                <time className="newsBox__itemTime" dateTime="2021-10-05">14:14</time>
                <a className="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27651355,nik-zarzuca-nieprawidlowosci-spolce-zaleznej-pgnig-21-5-mln.html#do_w=48&do_v=60&do_st=RS&do_sid=305&do_a=305&e=PSzLatLink2" title="NIK zarzuca nieprawidłowości spółce zależnej PGNiG. &quot;Konsekwencje finansowe przekroczyły 21,5 mln zł&quot;" data-bd-viewability={1} data-bd-viewability-id="newsBoxNewestList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27651355,nik-zarzuca-nieprawidlowosci-spolce-zaleznej-pgnig-21-5-mln.html#do_w=48&do_v=60&do_st=RS&do_sid=305&do_a=305&e=PSzLatLink2">
                  <span className="newsBox__itemTitle">NIK zarzuca nieprawidłowości spółce zależnej PGNiG. "Konsekwencje finansowe przekroczyły 21,5 mln zł"</span>
                </a>
              </li>
              <li className="newsBox__item">
                <time className="newsBox__itemTime" dateTime="2021-10-05">14:03</time>
                <a className="newsBox__itemLink" href="https://next.gazeta.pl/next/7,172392,27651299,szklarska-poreba-slynna-droga-pod-reglami-moze-zostac-zniszczona.html#do_w=48&do_v=60&do_st=RS&do_sid=305&do_a=305&e=PSzLatLink3" title="Szklarska Poręba. Słynna Droga pod Reglami zagrożona. Ma tam powstać obwodnica. &quot;Idiotyczny pomysł&quot;" data-bd-viewability={1} data-bd-viewability-id="newsBoxNewestList" data-bd-viewability-href="https://next.gazeta.pl/next/7,172392,27651299,szklarska-poreba-slynna-droga-pod-reglami-moze-zostac-zniszczona.html#do_w=48&do_v=60&do_st=RS&do_sid=305&do_a=305&e=PSzLatLink3">
                  <span className="newsBox__itemTitle">Szklarska Poręba. Słynna Droga pod Reglami zagrożona. Ma tam powstać obwodnica. "Idiotyczny pomysł"</span>
                </a>
              </li>
              <li className="newsBox__item">
                <time className="newsBox__itemTime" dateTime="2021-10-05">13:58</time>
                <a className="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27650367,nbp-o-gwarantowanym-kredycie-mieszkaniowym-ostrzega-przed-banka.html#do_w=48&do_v=60&do_st=RS&do_sid=305&do_a=305&e=PSzLatLink4" title="NBP ostrzega przed bańką cenową na rynku. Chodzi o gwarantowany kredyt mieszkaniowy" data-bd-viewability={1} data-bd-viewability-id="newsBoxNewestList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27650367,nbp-o-gwarantowanym-kredycie-mieszkaniowym-ostrzega-przed-banka.html#do_w=48&do_v=60&do_st=RS&do_sid=305&do_a=305&e=PSzLatLink4">
                  <span className="newsBox__itemTitle">NBP ostrzega przed bańką cenową na rynku. Chodzi o gwarantowany kredyt mieszkaniowy</span>
                </a>
              </li>
              <li className="newsBox__item">
                <time className="newsBox__itemTime" dateTime="2021-10-05">12:59</time>
                <a className="newsBox__itemLink" href="https://next.gazeta.pl/next/7,161716,27647449,65-cali-a-moze-jeszcze-wiecej-duze-telewizory-podbijaja-domy.html#do_w=48&do_v=60&do_st=RS&do_sid=305&do_a=305&e=PSzLatLink5" title="65 cali a może jeszcze więcej? Duże telewizory podbijają domy Polaków. Oto dlaczego" data-bd-viewability={1} data-bd-viewability-id="newsBoxNewestList" data-bd-viewability-href="https://next.gazeta.pl/next/7,161716,27647449,65-cali-a-moze-jeszcze-wiecej-duze-telewizory-podbijaja-domy.html#do_w=48&do_v=60&do_st=RS&do_sid=305&do_a=305&e=PSzLatLink5">
                  <span className="newsBox__itemTitle">65 cali a może jeszcze więcej? Duże telewizory podbijają domy Polaków. Oto dlaczego</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
  );
};