import React from 'react';
import {Breadcrumbs} from './Breadcrumbs';
import {SocialBar} from './SocialBar';
import RelatedImages from './RelatedImages';
import NewsBox from './NewsBox';
import Tags from './Tags';

export default function Article({ ...props }) {

    const data = props;
    // console.log('props', data)

      return (
<section id="article_wrapper" className="main_wrapper">

    <Breadcrumbs {...data} />

    <div className="left_aside">
        <SocialBar />
    </div>

    <h1 id="article_title" className="font-loaded">{data.title}</h1>

    <div className="ban000_wrapper">
        <div id="adUnit-000-MAINBOX" className="adviewDFPBanner DFP-000-MAINBOX activeBan">
            <span className="banLabel">REKLAMA</span>
        </div>
    </div>

    <div className="top_section">
        <div className="author_and_date" data-bd-viewability-id="author" data-bd-viewability="1">
            <span className="article_data">
                <span className="article_author">mk</span>
                <span className="article_date">
                    <time>05.10.2021 11:59</time>
                </span>
            </span>
        </div>
        <div id="gazeta_article_lead" className="font-loaded">{data.lead}</div>

        <RelatedImages {...data} />

    </div>

    <div className="ban001_wrapper">
        <div id="adUnit-001-TOPBOARD" className="adviewDFPBanner DFP-001-TOPBOARD activeBan">
        <span className="banLabel">REKLAMA</span>
        </div>
    </div>

    <div className="bottom_section">
        <div id="gazeta_article_body" data-bd-scroll-viewability="1" bd-scroll-pt="[25,50,75,100]">

            <section className="art_content" dangerouslySetInnerHTML={convert(data)}></section>

        </div>
        <Tags {...data}/>
    </div>

    <div className="right_aside">
        <div className="ban003_wrapper">
            <div id="adUnit-003-RECTANGLE" className="adviewDFPBanner DFP-003-RECTANGLE activeBan">
                <span className="banLabel">REKLAMA</span>
                <div id="div-gpt-ad-003-RECTANGLE-0" data-google-query-id="CMWk24evs_MCFRPSmgodAY0KDg">
                <div id="google_ads_iframe_/75224259/AGORA-IN/Next/003-RECTANGLE_0__container__"><iframe frameBorder="0" src="https://945d610509ca599ab5d9a913eec7b95a.safeframe.googlesyndication.com/safeframe/1-0-38/html/container.html" id="google_ads_iframe_/75224259/AGORA-IN/Next/003-RECTANGLE_0" title="3rd party ad content" name="" scrolling="no" marginWidth="0" marginHeight="0" width="300" height="600" data-is-safeframe="true" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" data-google-container-id="1" data-load-complete="true"></iframe></div></div>
            </div>
        </div>
        <div id="adUnit-021-IMK" className="adviewDFPBanner DFP-021-IMK activeBan" data-google-query-id="CJKM18yys_MCFcpGkQUdGNgN3g">

        <span className="banLabel">REKLAMA</span><div id="google_ads_iframe_/75224259/AGORA-IN/Next/021-IMK_0__container__" ><iframe frameBorder="0" src="https://945d610509ca599ab5d9a913eec7b95a.safeframe.googlesyndication.com/safeframe/1-0-38/html/container.html" id="google_ads_iframe_/75224259/AGORA-IN/Next/021-IMK_0" title="3rd party ad content" name="" scrolling="no" marginWidth="0" marginHeight="0" width="0" height="229" data-is-safeframe="true" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" data-google-container-id="8" data-load-complete="true"></iframe></div></div>

        <NewsBox {...data}/>

        <div id="adUnit-035-RECTANGLE-BTF" className="adviewDFPBanner DFP-035-RECTANGLE-BTF activeBan" data-google-query-id="CJ_tvpezs_MCFQvrmgodG7cFaw" >

        <span className="banLabel">REKLAMA</span><div id="google_ads_iframe_/75224259/AGORA-IN/Next/035-RECTANGLE-BTF_0__container__" ><iframe id="google_ads_iframe_/75224259/AGORA-IN/Next/035-RECTANGLE-BTF_0" title="3rd party ad content" name="google_ads_iframe_/75224259/AGORA-IN/Next/035-RECTANGLE-BTF_0" width="300" height="250" scrolling="no" marginWidth="0" marginHeight="0" frameBorder="0" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" srcDoc="" data-google-container-id="9" data-load-complete="true"></iframe></div></div>
    </div>

</section>
);
    }
//   };

function convert(data) {
    return {__html: data.body.replace(/\\"/g, '"')};
}
