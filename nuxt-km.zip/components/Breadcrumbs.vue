<template>
    <div id="sitePath">
		<ul id="breadcrumbs" data-bd-viewability-id="breadcrumbs" data-bd-viewability="1">
            <li class="bc_item" v-for="bc in data.breadcrumbs" :key="bc.title">
                <a v-if="bc.url" :href="bc.url" :title="bc.title" class="bc_item_link">{{bc.title}}</a>
                <span v-if="!bc.url">{{bc.title}}</span>
            </li>
        </ul>
    </div>
</template>


<script>
export default {
    props: ['data']
}
</script>