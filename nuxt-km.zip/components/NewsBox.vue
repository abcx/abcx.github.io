<template>
<div class="newsBox lazy_load">
    <div class="newsBox__header" style="left: 0px;">

        <div class="newsBox__tab newsBox--activeTab" data-tab="tab1">POPULARNE</div>
        <div class="newsBox__tab" data-tab="tab2">NAJNOWSZE</div>

        </div>
    <div class="newsBox__content" style="height: 532px; transform: translateX(0px);">
        <div class="newsBox__contentElement newsBox__popularList newsBox__photoVersion">
            <ul>
                <li class="newsBox__item">
                            <a class="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27649758,facebook-juz-dziala-jest-komunikat-firmy-o-przyczynach-bledna.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=417&amp;do_a=417&amp;e=PSzPopImg1" title="Facebook działa. Koniec największej awarii w historii firmy. Jest komunikat o przyczynach" data-bd-viewability="1" data-bd-viewability-id="newsBoxPopularList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27649758,facebook-juz-dziala-jest-komunikat-firmy-o-przyczynach-bledna.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=417&amp;do_a=417&amp;e=PSzPopImg1">
                                <span class="newsBox__itemPhotoBox">
                                        <noscript>
                                            <img class="newsBox__itemPhoto" src="https://bi.im-g.pl/im/df/5e/1a/z27649759F,Facebook.jpg" alt="Facebook działa. Koniec największej awarii w historii firmy. Jest komunikat o przyczynach" />
                                        </noscript>
                                        <img class="newsBox__itemPhoto loaded" src="https://bi.im-g.pl/im/df/5e/1a/z27649759F,Facebook.jpg" data-src="https://bi.im-g.pl/im/df/5e/1a/z27649759F,Facebook.jpg" alt="Facebook działa. Koniec największej awarii w historii firmy. Jest komunikat o przyczynach">
                                    </span>
                                <span class="newsBox__itemTitle">Facebook działa. Koniec największej awarii w historii firmy. Jest komunikat o przyczynach</span>
                            </a>
                        </li>

                    <li class="newsBox__item">
                            <a class="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27635633,skrajne-ubostwo-wyeliminowalibysmy-za-ulamek-kwoty-ktora-wydajemy.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=417&amp;do_a=417&amp;e=PSzPopImg2" title="&quot;Skrajne ubóstwo wyeliminowalibyśmy za ułamek kwoty, którą wydajemy na 500 plus. Ale to niewykonalne&quot;" data-bd-viewability="1" data-bd-viewability-id="newsBoxPopularList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27635633,skrajne-ubostwo-wyeliminowalibysmy-za-ulamek-kwoty-ktora-wydajemy.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=417&amp;do_a=417&amp;e=PSzPopImg2">
                                <span class="newsBox__itemPhotoBox">
                                        <noscript>
                                            <img class="newsBox__itemPhoto" src="https://bi.im-g.pl/im/69/5b/1a/z27636585F,DLOLO.jpg" alt="&#034;Skrajne ubóstwo wyeliminowalibyśmy za ułamek kwoty, którą wydajemy na 500 plus. Ale to niewykonalne&#034;" />
                                        </noscript>
                                        <img class="newsBox__itemPhoto loaded" src="https://bi.im-g.pl/im/69/5b/1a/z27636585F,DLOLO.jpg" data-src="https://bi.im-g.pl/im/69/5b/1a/z27636585F,DLOLO.jpg" alt="&quot;Skrajne ubóstwo wyeliminowalibyśmy za ułamek kwoty, którą wydajemy na 500 plus. Ale to niewykonalne&quot;">
                                    </span>
                                <span class="newsBox__itemTitle">"Skrajne ubóstwo wyeliminowalibyśmy za ułamek kwoty, którą wydajemy na 500 plus. Ale to niewykonalne"</span>
                            </a>
                        </li>

                    <li class="newsBox__item">
                            <a class="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27647177,grozna-sytuacja-na-otwarciu-drogi-s7-szalenie-niebezpieczne.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=417&amp;do_a=417&amp;e=PSzPopImg3" title="Groźna sytuacja na otwarciu drogi S7? &quot;Szalenie niebezpieczne&quot;, &quot;Tupolewizm wiecznie żywy&quot;" data-bd-viewability="1" data-bd-viewability-id="newsBoxPopularList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27647177,grozna-sytuacja-na-otwarciu-drogi-s7-szalenie-niebezpieczne.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=417&amp;do_a=417&amp;e=PSzPopImg3">
                                <span class="newsBox__itemPhotoBox">
                                        <noscript>
                                            <img class="newsBox__itemPhoto" src="https://bi.im-g.pl/im/9c/5d/1a/z27647388F,Otwarcie-fragmentu-drogi-ekspresowej-S7.jpg" alt="Groźna sytuacja na otwarciu drogi S7? &#034;Szalenie niebezpieczne&#034;, &#034;Tupolewizm wiecznie żywy&#034;" />
                                        </noscript>
                                        <img class="newsBox__itemPhoto loaded" src="https://bi.im-g.pl/im/9c/5d/1a/z27647388F,Otwarcie-fragmentu-drogi-ekspresowej-S7.jpg" data-src="https://bi.im-g.pl/im/9c/5d/1a/z27647388F,Otwarcie-fragmentu-drogi-ekspresowej-S7.jpg" alt="Groźna sytuacja na otwarciu drogi S7? &quot;Szalenie niebezpieczne&quot;, &quot;Tupolewizm wiecznie żywy&quot;">
                                    </span>
                                <span class="newsBox__itemTitle">Groźna sytuacja na otwarciu drogi S7? "Szalenie niebezpieczne", "Tupolewizm wiecznie żywy"</span>
                            </a>
                        </li>

                    <li class="newsBox__item">
                            <a class="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151243,27650216,facebook-nie-mogl-naprawic-facebooka-bo-facebook-trzyma-wszystko.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=417&amp;do_a=417&amp;e=PSzPopImg4" title="Facebook nie mógł naprawić Facebooka, bo Facebook trzyma wszystko na Facebooku" data-bd-viewability="1" data-bd-viewability-id="newsBoxPopularList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151243,27650216,facebook-nie-mogl-naprawic-facebooka-bo-facebook-trzyma-wszystko.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=417&amp;do_a=417&amp;e=PSzPopImg4">
                                <span class="newsBox__itemPhotoBox">
                                        <noscript>
                                            <img class="newsBox__itemPhoto" src="https://bi.im-g.pl/im/eb/6f/19/z26671339F,Mark-Zuckerberg.jpg" alt="Facebook nie mógł naprawić Facebooka, bo Facebook trzyma wszystko na Facebooku" />
                                        </noscript>
                                        <img class="newsBox__itemPhoto loaded" src="https://bi.im-g.pl/im/eb/6f/19/z26671339F,Mark-Zuckerberg.jpg" data-src="https://bi.im-g.pl/im/eb/6f/19/z26671339F,Mark-Zuckerberg.jpg" alt="Facebook nie mógł naprawić Facebooka, bo Facebook trzyma wszystko na Facebooku">
                                    </span>
                                <span class="newsBox__itemTitle">Facebook nie mógł naprawić Facebooka, bo Facebook trzyma wszystko na Facebooku</span>
                            </a>
                        </li>

                    <li class="newsBox__item">
                            <a class="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27647040,polski-lad-emerytury-wzrosna-nawet-o-187-zl-ale-sa-tez-tacy.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=417&amp;do_a=417&amp;e=PSzPopImg5" title="Polski Ład. Emerytury wzrosną nawet o 187 zł. Ale są też tacy, którym świadczenie spadnie [TABELA]" data-bd-viewability="1" data-bd-viewability-id="newsBoxPopularList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27647040,polski-lad-emerytury-wzrosna-nawet-o-187-zl-ale-sa-tez-tacy.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=417&amp;do_a=417&amp;e=PSzPopImg5">
                                <span class="newsBox__itemPhotoBox">
                                        <noscript>
                                            <img class="newsBox__itemPhoto" src="https://bi.im-g.pl/im/37/5b/1a/z27638839F,Emerytura--zdjecie-ilustracyjne-.jpg" alt="Polski Ład. Emerytury wzrosną nawet o 187 zł. Ale są też tacy, którym świadczenie spadnie [TABELA]" />
                                        </noscript>
                                        <img class="newsBox__itemPhoto loaded" src="https://bi.im-g.pl/im/37/5b/1a/z27638839F,Emerytura--zdjecie-ilustracyjne-.jpg" data-src="https://bi.im-g.pl/im/37/5b/1a/z27638839F,Emerytura--zdjecie-ilustracyjne-.jpg" alt="Polski Ład. Emerytury wzrosną nawet o 187 zł. Ale są też tacy, którym świadczenie spadnie [TABELA]">
                                    </span>
                                <span class="newsBox__itemTitle">Polski Ład. Emerytury wzrosną nawet o 187 zł. Ale są też tacy, którym świadczenie spadnie [TABELA]</span>
                            </a>
                        </li>

                    </ul>
        </div>
        <div class="newsBox__contentElement newsBox__newestList">
            <ul>
                <li class="newsBox__item">
                            <time class="newsBox__itemTime" datetime="2021-10-05">14:50</time>
                            <a class="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27651758,knf-ostrzega-oszusci-stworzyli-falszywa-strone-banku-credit.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=305&amp;do_a=305&amp;e=PSzLatLink1" title="KNF ostrzega. Oszuści stworzyli fałszywą stronę banku Credit Agricole, aby wyłudzać dane" data-bd-viewability="1" data-bd-viewability-id="newsBoxNewestList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27651758,knf-ostrzega-oszusci-stworzyli-falszywa-strone-banku-credit.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=305&amp;do_a=305&amp;e=PSzLatLink1">
                                <span class="newsBox__itemTitle">KNF ostrzega. Oszuści stworzyli fałszywą stronę banku Credit Agricole, aby wyłudzać dane</span>
                            </a>
                        </li>

                    <li class="newsBox__item">
                            <time class="newsBox__itemTime" datetime="2021-10-05">14:14</time>
                            <a class="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27651355,nik-zarzuca-nieprawidlowosci-spolce-zaleznej-pgnig-21-5-mln.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=305&amp;do_a=305&amp;e=PSzLatLink2" title="NIK zarzuca nieprawidłowości spółce zależnej PGNiG. &quot;Konsekwencje finansowe przekroczyły 21,5 mln zł&quot;" data-bd-viewability="1" data-bd-viewability-id="newsBoxNewestList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27651355,nik-zarzuca-nieprawidlowosci-spolce-zaleznej-pgnig-21-5-mln.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=305&amp;do_a=305&amp;e=PSzLatLink2">
                                <span class="newsBox__itemTitle">NIK zarzuca nieprawidłowości spółce zależnej PGNiG. "Konsekwencje finansowe przekroczyły 21,5 mln zł"</span>
                            </a>
                        </li>

                    <li class="newsBox__item">
                            <time class="newsBox__itemTime" datetime="2021-10-05">14:03</time>
                            <a class="newsBox__itemLink" href="https://next.gazeta.pl/next/7,172392,27651299,szklarska-poreba-slynna-droga-pod-reglami-moze-zostac-zniszczona.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=305&amp;do_a=305&amp;e=PSzLatLink3" title="Szklarska Poręba. Słynna Droga pod Reglami zagrożona. Ma tam powstać obwodnica. &quot;Idiotyczny pomysł&quot;" data-bd-viewability="1" data-bd-viewability-id="newsBoxNewestList" data-bd-viewability-href="https://next.gazeta.pl/next/7,172392,27651299,szklarska-poreba-slynna-droga-pod-reglami-moze-zostac-zniszczona.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=305&amp;do_a=305&amp;e=PSzLatLink3">
                                <span class="newsBox__itemTitle">Szklarska Poręba. Słynna Droga pod Reglami zagrożona. Ma tam powstać obwodnica. "Idiotyczny pomysł"</span>
                            </a>
                        </li>

                    <li class="newsBox__item">
                            <time class="newsBox__itemTime" datetime="2021-10-05">13:58</time>
                            <a class="newsBox__itemLink" href="https://next.gazeta.pl/next/7,151003,27650367,nbp-o-gwarantowanym-kredycie-mieszkaniowym-ostrzega-przed-banka.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=305&amp;do_a=305&amp;e=PSzLatLink4" title="NBP ostrzega przed bańką cenową na rynku. Chodzi o gwarantowany kredyt mieszkaniowy" data-bd-viewability="1" data-bd-viewability-id="newsBoxNewestList" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27650367,nbp-o-gwarantowanym-kredycie-mieszkaniowym-ostrzega-przed-banka.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=305&amp;do_a=305&amp;e=PSzLatLink4">
                                <span class="newsBox__itemTitle">NBP ostrzega przed bańką cenową na rynku. Chodzi o gwarantowany kredyt mieszkaniowy</span>
                            </a>
                        </li>

                    <li class="newsBox__item">
                            <time class="newsBox__itemTime" datetime="2021-10-05">12:59</time>
                            <a class="newsBox__itemLink" href="https://next.gazeta.pl/next/7,161716,27647449,65-cali-a-moze-jeszcze-wiecej-duze-telewizory-podbijaja-domy.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=305&amp;do_a=305&amp;e=PSzLatLink5" title="65 cali a może jeszcze więcej? Duże telewizory podbijają domy Polaków. Oto dlaczego" data-bd-viewability="1" data-bd-viewability-id="newsBoxNewestList" data-bd-viewability-href="https://next.gazeta.pl/next/7,161716,27647449,65-cali-a-moze-jeszcze-wiecej-duze-telewizory-podbijaja-domy.html#do_w=48&amp;do_v=60&amp;do_st=RS&amp;do_sid=305&amp;do_a=305&amp;e=PSzLatLink5">
                                <span class="newsBox__itemTitle">65 cali a może jeszcze więcej? Duże telewizory podbijają domy Polaków. Oto dlaczego</span>
                            </a>
                        </li>

                    </ul>
        </div>
        </div>
</div>
</template>


<script>
export default {
    props: ['data']
}
</script>