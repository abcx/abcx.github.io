<template>
  <section id="article_wrapper" class="main_wrapper">
   <Breadcrumbs :data="article"/>
    <div class="left_aside">
        <SocialBar/>
    </div>
    
    <h1 id="article_title" class="font-loaded">{{api.title}}</h1>
    <div class="ban000_wrapper">
        <div id="adUnit-000-MAINBOX" class="adviewDFPBanner DFP-000-MAINBOX">
            <span class="banLabel" style="display: none;">REKLAMA</span>
            <div id="div-gpt-ad-000-MAINBOX-0" data-google-query-id="COWj8rjAx_MCFZOBmgodobIFew" style="display: none;">
                <div id="google_ads_iframe_/75224259/AGORA-IN/Next/000-MAINBOX_0__container__" style="border: 0pt none; width: 300px; height: 100px;">
                </div>
            </div>
        </div>
    </div>

    <div class="top_section">
        <div class="author_and_date" data-bd-viewability-id="author" data-bd-viewability="1">
            <span class="article_data">
                <span class="article_author" itemprop="author">mk</span>
                <span class="article_date">
                    <time datetime="2021-10-05 11:59">05.10.2021 11:59</time>
                </span>
            </span>
        </div>
        <div id="gazeta_article_lead" class="font-loaded">{{api.lead}}</div>
        <RelatedImages :data="api.photoRelated"/>
    </div>
    <div class="ban001_wrapper">
        <div id="adUnit-001-TOPBOARD" class="adviewDFPBanner DFP-001-TOPBOARD activeBan" style="margin-left: auto; margin-right: auto; min-width: 1170px; max-width: 1170px;">
        <span class="banLabel" style="display: block; max-width: 1170px; margin-left: auto; margin-right: auto;">REKLAMA</span>
        </div>
    </div>

    <div class="bottom_section">
        <div id="gazeta_article_body" data-bd-scroll-viewability="1" bd-scroll-pt="[25,50,75,100]">

            <div v-html="api.documentContent"></div>
            <script type="application/ld+json">{"mainEntityOfPage":{"url":"https://next.gazeta.pl/next/7,172690,27650905,nagroda-nobla-2021-akademia-oglosila-nazwiska-laureatow-w-dziedzinie.html","@type":"WebPage"},"headline":"Nagroda Nobla 2021. Akademia ogłosiła nazwiska laureatów w dziedzinie fizyki. Klimat w tle","datePublished":"2021-10-05T09:59:54Z","dateModified":"2021-10-05T10:25:23Z","articleSection":"next","description":"Królewska Szwedzka Akademia Nauk postanowiła przyznać Nagrodę Nobla w dziedzinie fizyki 2021 \"za przełomowy wkład w nasze zrozumienie złożonych systemów fizycznych\" trzem naukowcom. W tym roku nagrodę otrzymują: 90-letni Syukuro Manabe (Uniwersytet Princeton, USA), 90-letni Klaus Hasselmann (Instytut Meteorologii im. Maxa Plancka, Hamburg, Niemcy) i 72-letni Giorgio Parisi (Uniwersytet Sapienza w Rzymie).","publisher":{"@type":"Organization","name":"next.gazeta.pl","logo":{"url":"https://next.gazeta.pl/logos/0.png","@type":"ImageObject"}},"author":[{"name":"mk","@type":"Person"}],"@context":"http://schema.org","@type":"NewsArticle","name":"Nagroda Nobla 2021. Akademia ogłosiła nazwiska laureatów w dziedzinie fizyki. Klimat w tle","image":[{"url":"https://bi.im-g.pl/im/ee/5e/1a/z27651054V,Nagroda-Nobla-z-fizyki--Ogloszenie-zwyciezcow.jpg","name":"Nagroda Nobla z fizyki. Ogłoszenie zwycięzców","@type":"ImageObject"},{"url":"https://bi.im-g.pl/im/e0/5e/1a/z27651040V,Nagroda-Nobla-z-fizyki--Zdjecie-ilustracyjne.jpg","name":"Nagroda Nobla z fizyki. Zdjęcie ilustracyjne","@type":"ImageObject"}]}</script>

        </div>
        <Tags :data="api.tags"/>
    </div>

    <div class="right_aside">
        <div class="ban003_wrapper">
            <div id="adUnit-003-RECTANGLE" class="adviewDFPBanner DFP-003-RECTANGLE activeBan" style="margin-left: auto; margin-right: auto; min-width: 300px; max-width: 300px;">
                <span class="banLabel" style="display: block; max-width: 300px; margin-left: auto; margin-right: auto;">REKLAMA</span>
                <div id="div-gpt-ad-003-RECTANGLE-0" style="" data-google-query-id="CMWk24evs_MCFRPSmgodAY0KDg"></div>
                <div id="google_ads_iframe_/75224259/AGORA-IN/Next/003-RECTANGLE_0__container__" style="border: 0pt none; display: inline-block; width: 300px; height: 600px;">
                    <iframe frameborder="0" src="https://945d610509ca599ab5d9a913eec7b95a.safeframe.googlesyndication.com/safeframe/1-0-38/html/container.html" id="google_ads_iframe_/75224259/AGORA-IN/Next/003-RECTANGLE_0" title="3rd party ad content" name="" scrolling="no" marginwidth="0" marginheight="0" width="300" height="600" data-is-safeframe="true" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" data-google-container-id="1" style="border: 0px; vertical-align: bottom;" data-load-complete="true">
                    </iframe>
                </div>
            </div>
        </div>

        <div id="adUnit-021-IMK" class="adviewDFPBanner DFP-021-IMK activeBan" data-google-query-id="CJKM18yys_MCFcpGkQUdGNgN3g">
            <span class="banLabel" style="display: block;">REKLAMA</span>
            <div id="google_ads_iframe_/75224259/AGORA-IN/Next/021-IMK_0__container__" style="border: 0pt none; display: inline-block; width: 100%; height: auto;">
                <iframe frameborder="0" src="https://945d610509ca599ab5d9a913eec7b95a.safeframe.googlesyndication.com/safeframe/1-0-38/html/container.html" id="google_ads_iframe_/75224259/AGORA-IN/Next/021-IMK_0" title="3rd party ad content" name="" scrolling="no" marginwidth="0" marginheight="0" width="0" height="229" data-is-safeframe="true" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" data-google-container-id="8" style="border: 0px; vertical-align: bottom; min-width: 100%;" data-load-complete="true">
                </iframe>
            </div>
        </div>
        <NewsBox/> 
    </div>
  </section>
</template>


<script>
import axios from 'axios';
import article from '@/article.json';

export default {
   
   data() {
      return {
          api: {},
          article: article,
        }
    },

    async fetch() {

        const headers = { 
            "Content-Type": "application/json"
        };

        await this.$axios.$get("https://bi.gazeta.pl/aliasy/test/app-config/article-data.json", { headers })
            .then(response => {
                this.api = response;
            });  ;
    }
}
</script>
