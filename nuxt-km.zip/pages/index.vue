<template>
  <div>
    <component :is="layout"></component>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';

const staticConfig = {
  "layout": "normal",
  "article": [
    "breadcrumbs",
    "tags" 
  ],
  "news": [
    "popular",
    "news",
    "recommendations"
  ],
  "recommendationsPremium": {
    "articleRelated": [
      "ads",
      "author"
    ],
    "articleRelatedWithQuiz": [
      "ads",
      "author"
    ]
  }
};

export default Vue.extend({
  components: {
		'normal': () => import('@/components/MainNormalLayout.vue'),
		'premium': () => import('@/components/MainPremiumLayout.vue')
	},
	data() {
		return {
			config: staticConfig,
      layout: this.$route.query.layout || 'normal'
		}
	}
})

</script>