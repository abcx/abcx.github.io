<template>
<div class="related_images">
    <div class="related_image_wrap with_gallery">
        <div data-hyb-ssp-in-image-overlay="5f16cfb27bc72fa3a087e1ba" data-hyb-ssp-ad-place-status="empty">           
           <img :src="changePhotoFormat(data[0] && data[0].url,'IH')" :alt="data[0].title" :title="data[0].title">
        </div>
        <div class="related_image_number_of_photo">
            <svg xmlns="http://www.w3.org/2000/svg" width="21.6" height="18" viewBox="0 0 21.6 18">
                <g transform="translate(-431 -2615.599)">
                    <path style="fill: #222" d="M67.471,67.591H67.1v-9.55h13.13v.367a.837.837,0,0,0,0,.166.9.9,0,0,0,.982.814h.028a.967.967,0,0,0,.954-.98V57.156a.969.969,0,0,0-.982-.952H66.244a1.054,1.054,0,0,0-.982.98V68.571a.148.148,0,0,0,0,.028.966.966,0,0,0,.982.951h1.287a.98.98,0,1,0-.06-1.959Z" transform="translate(365.739 2559.396)"></path>
                    <path style="fill: #222" d="M85.381,60.738H71.636A1.885,1.885,0,0,0,69.8,62.575V72.737a1.884,1.884,0,0,0,1.841,1.837H85.258A1.885,1.885,0,0,0,87.1,72.737h.123V62.575A1.886,1.886,0,0,0,85.381,60.738Zm.041,12.032H71.57V62.528H85.422Z" transform="translate(365.378 2559.025)"></path>
                </g>
            </svg>
            <div class="related_image_number">2</div>
        </div>
    </div>
    <p class="desc">YouTube.com/Nobel Prize</p>
    <div class="related_image_open">
        <p class="related_open_text">
            <svg class="related-icon" viewBox="0 0 21.6 18"><g transform="translate(-431 -2615.6)"><path class="gallery_icon" d="M67.471,67.591H67.1v-9.55H80.233v.367a.837.837,0,0,0,0,.166.9.9,0,0,0,.982.814h.028a.967.967,0,0,0,.954-.98V57.156a.969.969,0,0,0-.982-.952H66.244a1.054,1.054,0,0,0-.982.98V68.571a.147.147,0,0,0,0,.028.966.966,0,0,0,.982.951h1.287a.98.98,0,1,0-.06-1.959Z" transform="translate(365.739 2559.396)"></path><path class="gallery_icon" d="M85.381,60.738H71.636a1.885,1.885,0,0,0-1.841,1.837V72.738a1.884,1.884,0,0,0,1.841,1.837H85.258A1.885,1.885,0,0,0,87.1,72.738h.123V62.575A1.886,1.886,0,0,0,85.381,60.738Zm.041,12.032H71.57V62.528H85.422Z" transform="translate(365.378 2559.025)"></path></g></svg>
            <span class="related_open_label">Otwórz galerię </span> <span class="related_gazetaPL">Na Gazeta.pl</span>
        </p>
    </div>
</div>
</template>

<script>
export default {
    props: ['data'],
    methods: {
        changePhotoFormat(url, newFormat) {
            const REGEX_PHOTO_FORMAT = /(z\d+)[A-Z]+/;
            const REGEX_PHOTO_PATH = /(https?:)?\/\/.*pl\/im\//;
            const IMAGE_PATH = 'https://bi.im-g.pl/im/';

            return url
                .replace(REGEX_PHOTO_PATH, IMAGE_PATH)
                .replace(REGEX_PHOTO_FORMAT, '$1' + newFormat);
        }
    }
}
</script>