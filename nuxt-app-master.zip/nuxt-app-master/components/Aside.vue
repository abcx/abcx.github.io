<template>
<div class="aside_wrapper section_wrapper">
    <div class="content_wrap">
        <div class="recommendations lazy_load" role="tablist">
    <input type="radio" name="recommendations_tab" id="recommendations_tab1" class="hidden">
    <label role="tab" class="tab" for="recommendations_tab1">polecamy</label>
    <input type="radio" name="recommendations_tab" id="recommendations_tab2" class="hidden">
    <label role="tab" class="tab" for="recommendations_tab2">więcej tematów</label>
    <div class="recommendations_box" id="recommendations_content1">
        <section class="related_articles lazy_load">
        <ul class="related_articles_list">
            <li class="related_article">
                    <a class="related_article_link " href="https://next.gazeta.pl/next/7,151003,27651758,knf-ostrzega-oszusci-stworzyli-falszywa-strone-banku-credit.html#e=RelRecImg1" title="KNF ostrzega. Oszuści stworzyli fałszywą stronę banku Credit Agricole, aby wyłudzać dane" data-bd-viewability="1" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27651758,knf-ostrzega-oszusci-stworzyli-falszywa-strone-banku-credit.html#e=RelRecImg1" data-bd-viewability-id="related_article">
    <noscript>
        <img class="related_article_photo" src="https://bi.im-g.pl/im/e9/5e/1a/z27651817II,Falszywa-strona-internetowa-Credit-Agricole.jpg" alt="Fałszywa strona internetowa Credit Agricole" />
    </noscript>
    <img src="https://bi.im-g.pl/im/e9/5e/1a/z27651817II,Falszywa-strona-internetowa-Credit-Agricole.jpg" class="related_article_photo loaded" data-src="https://bi.im-g.pl/im/e9/5e/1a/z27651817II,Falszywa-strona-internetowa-Credit-Agricole.jpg" alt="Fałszywa strona internetowa Credit Agricole">
    <span class="related_article_title">KNF ostrzega. Oszuści stworzyli fałszywą stronę banku Credit Agricole, aby wyłudzać dane</span>
</a></li>
            <li class="related_article">
                    <div id="adUnit-091-RELATED" class="adviewDFPBanner DFP-091-RELATED activeBan" data-google-query-id="CIHR77izs_MCFWibsgodwCoGzg">


    <div id="google_ads_iframe_/75224259/AGORA-IN/Next/091-RELATED_0__container__" style="border: 0pt none; visibility: visible; min-width: 100%;"><iframe id="google_ads_iframe_/75224259/AGORA-IN/Next/091-RELATED_0" title="3rd party ad content" name="google_ads_iframe_/75224259/AGORA-IN/Next/091-RELATED_0" width="218" height="201" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" srcdoc="" style="border: 0px; vertical-align: bottom; min-width: 100%;" data-google-container-id="c" data-load-complete="true"></iframe></div></div>
<!-- v1.0 -->
<!--410356653, [ /tpl/ads/prod/dfpSlotScripts.jsp ], dfpBanersSlotScriptsBean-->
<!-- v2.2.2 -->
<!--410356674, [ /tpl/ads/prod/dfpSlot.jsp ], dfpBanersSlotBean-->
<a class="related_article_link related_article_link--ifAdHidden" href="https://next.gazeta.pl/next/7,151003,27651355,nik-zarzuca-nieprawidlowosci-spolce-zaleznej-pgnig-21-5-mln.html#e=RelRecImg2" title="NIK zarzuca nieprawidłowości spółce zależnej PGNiG. &quot;Konsekwencje finansowe przekroczyły 21,5 mln zł&quot;" data-bd-viewability="1" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27651355,nik-zarzuca-nieprawidlowosci-spolce-zaleznej-pgnig-21-5-mln.html#e=RelRecImg2" data-bd-viewability-id="related_article">
    <noscript>
        <img class="related_article_photo" src="https://bi.im-g.pl/im/8f/5e/1a/z27651471II,NIK-skontrolowal-spolke-Exalo.jpg" alt="NIK skontrolował spółkę Exalo" />
    </noscript>
    <img src="https://bi.im-g.pl/im/8f/5e/1a/z27651471II,NIK-skontrolowal-spolke-Exalo.jpg" class="related_article_photo loaded" data-src="https://bi.im-g.pl/im/8f/5e/1a/z27651471II,NIK-skontrolowal-spolke-Exalo.jpg" alt="NIK skontrolował spółkę Exalo">
    <span class="related_article_title">NIK zarzuca nieprawidłowości spółce zależnej PGNiG. "Konsekwencje finansowe przekroczyły 21,5 mln zł"</span>
</a></li>
            <li class="related_article">
                    <a class="related_article_link " href="https://next.gazeta.pl/next/7,172392,27651299,szklarska-poreba-slynna-droga-pod-reglami-moze-zostac-zniszczona.html#e=RelRecImg3" title="Szklarska Poręba. Słynna Droga pod Reglami zagrożona. Ma tam powstać obwodnica. &quot;Idiotyczny pomysł&quot;" data-bd-viewability="1" data-bd-viewability-href="https://next.gazeta.pl/next/7,172392,27651299,szklarska-poreba-slynna-droga-pod-reglami-moze-zostac-zniszczona.html#e=RelRecImg3" data-bd-viewability-id="related_article">
    <noscript>
        <img class="related_article_photo" src="https://bi.im-g.pl/im/b9/5e/1a/z27651513II,Protest-przeciwko-asfaltowaniu-Drogi-pod-Reglami-w.jpg" alt="Protest przeciwko asfaltowaniu Drogi pod Reglami w Karkonoszach" />
    </noscript>
    <img src="https://bi.im-g.pl/im/b9/5e/1a/z27651513II,Protest-przeciwko-asfaltowaniu-Drogi-pod-Reglami-w.jpg" class="related_article_photo loaded" data-src="https://bi.im-g.pl/im/b9/5e/1a/z27651513II,Protest-przeciwko-asfaltowaniu-Drogi-pod-Reglami-w.jpg" alt="Protest przeciwko asfaltowaniu Drogi pod Reglami w Karkonoszach">
    <span class="related_article_title">Szklarska Poręba. Słynna Droga pod Reglami zagrożona. Ma tam powstać obwodnica. "Idiotyczny pomysł"</span>
</a></li>
            <li class="related_article">
                    <a class="related_article_link " href="https://next.gazeta.pl/next/7,151003,27650367,nbp-o-gwarantowanym-kredycie-mieszkaniowym-ostrzega-przed-banka.html#e=RelRecImg4" title="NBP ostrzega przed bańką cenową na rynku. Chodzi o gwarantowany kredyt mieszkaniowy" data-bd-viewability="1" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27650367,nbp-o-gwarantowanym-kredycie-mieszkaniowym-ostrzega-przed-banka.html#e=RelRecImg4" data-bd-viewability-id="related_article">
    <noscript>
        <img class="related_article_photo" src="https://bi.im-g.pl/im/7b/d6/18/z26044283II,Zdjecie-ilustracyjne.jpg" alt="Zdjęcie ilustracyjne" />
    </noscript>
    <img src="https://bi.im-g.pl/im/7b/d6/18/z26044283II,Zdjecie-ilustracyjne.jpg" class="related_article_photo loaded" data-src="https://bi.im-g.pl/im/7b/d6/18/z26044283II,Zdjecie-ilustracyjne.jpg" alt="Zdjęcie ilustracyjne">
    <span class="related_article_title">NBP ostrzega przed bańką cenową na rynku. Chodzi o gwarantowany kredyt mieszkaniowy</span>
</a></li>
            <li class="related_article">
                    <a class="related_article_link " href="https://next.gazeta.pl/next/7,161716,27647449,65-cali-a-moze-jeszcze-wiecej-duze-telewizory-podbijaja-domy.html#e=RelRecImg5" title="65 cali a może jeszcze więcej? Duże telewizory podbijają domy Polaków. Oto dlaczego" data-bd-viewability="1" data-bd-viewability-href="https://next.gazeta.pl/next/7,161716,27647449,65-cali-a-moze-jeszcze-wiecej-duze-telewizory-podbijaja-domy.html#e=RelRecImg5" data-bd-viewability-id="related_article">
    <noscript>
        <img class="related_article_photo" src="https://bi.im-g.pl/im/f5/5d/1a/z27647477II,Telewizor-Samsung.jpg" alt="Telewizor Samsung" />
    </noscript>
    <img src="https://bi.im-g.pl/im/f5/5d/1a/z27647477II,Telewizor-Samsung.jpg" class="related_article_photo loaded" data-src="https://bi.im-g.pl/im/f5/5d/1a/z27647477II,Telewizor-Samsung.jpg" alt="Telewizor Samsung">
    <span class="related_article_title">65 cali a może jeszcze więcej? Duże telewizory podbijają domy Polaków. Oto dlaczego</span>
</a></li>
            <li class="related_article">
                    <a class="related_article_link " href="https://next.gazeta.pl/next/7,151003,27650903,awaria-facebooka-mark-zuckerberg-stracil-na-niej-miliardy-dolarow.html#e=RelRecImg6" title="Awaria Facebooka. Mark Zuckerberg stracił miliardy dolarów. I spadł na 5. miejsce listy najbogatszych" data-bd-viewability="1" data-bd-viewability-href="https://next.gazeta.pl/next/7,151003,27650903,awaria-facebooka-mark-zuckerberg-stracil-na-niej-miliardy-dolarow.html#e=RelRecImg6" data-bd-viewability-id="related_article">
    <noscript>
        <img class="related_article_photo" src="https://bi.im-g.pl/im/04/5e/1a/z27651076II,Mark-Zuckerberg--zdjecie-ilustracyjne.jpg" alt="Mark Zuckerberg, zdjęcie ilustracyjne" />
    </noscript>
    <img src="https://bi.im-g.pl/im/04/5e/1a/z27651076II,Mark-Zuckerberg--zdjecie-ilustracyjne.jpg" class="related_article_photo loaded" data-src="https://bi.im-g.pl/im/04/5e/1a/z27651076II,Mark-Zuckerberg--zdjecie-ilustracyjne.jpg" alt="Mark Zuckerberg, zdjęcie ilustracyjne">
    <span class="related_article_title">Awaria Facebooka. Mark Zuckerberg stracił miliardy dolarów. I spadł na 5. miejsce listy najbogatszych</span>
</a></li>
            </ul>
    </section>

<!--410356687, [ /tpl/prod/modules/related/related.jsp ], quizAwareRelatedModule-->
<section class="related_quiz lazy_load" data-position="quizy" data-bd-viewability-id="related_quiz" data-bd-viewability="1">
			<div class="related_quiz_container" style="">
				<header class="related_quiz_header">
						<h3 class="related_quiz_title">W ilu językach potrafisz się przywitać? Sprawdź, czy masz szansę zostać poliglotą</h3>
					</header>
				<div class="related_quiz_body">
					<form action="//next.gazeta.pl/next/13,172690,12573.html?i=1#e=RelRecQuiz" name="formData" method="post" class="quiz_question question_stage">
						<div class="quiz_open_image">
								<img data-src="https://bi.im-g.pl/im/6d/8a/12/z19439725MS,Londyn.jpg" src="https://bi.im-g.pl/im/6d/8a/12/z19439725MS,Londyn.jpg" class="loaded">
							</div>
						<div class="question_content">
							<span class="number_of_questions">Pytanie 1 z 12</span>
								<strong class="question_title">
										Na początek proste pytanie. "Hello" to powitanie w języku:</strong>
								<fieldset class="answer_fields">
											<input type="radio" name="answer_0" id="answer_0_1" value="0" class="answer_btn">
											<label for="answer_0_1" class="answer_label">
												<span class="answer_txt">niemieckim</span>
											</label>
										</fieldset>
									<fieldset class="answer_fields">
											<input type="radio" name="answer_0" id="answer_0_2" value="1" class="answer_btn">
											<label for="answer_0_2" class="answer_label">
												<span class="answer_txt">francuskim</span>
											</label>
										</fieldset>
									<fieldset class="answer_fields">
											<input type="radio" name="answer_0" id="answer_0_3" value="2" class="answer_btn">
											<label for="answer_0_3" class="answer_label">
												<span class="answer_txt">angielskim</span>
											</label>
										</fieldset>
									<input type="submit" value="Następne" disabled="true" class="submit_btn">
							<input type="hidden" name="quizQuestionNumber" value="1">
							</div>
					</form>
				</div>
			</div>
		</section>

<!--410356609, [ /tpl/prod/modules/quiz/quiz.jsp ], quizModule-->
</div>
    <div class="recommendations_box" id="recommendations_content2" data-bd-viewability-id="recommendationsMore" data-bd-viewability="1">
        <div class="box_seo">
<ul class="content">
<li class="seo_column">
<h3>
Zakupy
</h3>
<ul>
<li class="seo_row">
<a href="https://zakupy.avanti24.pl/mokasyny/nessi/damskie" title="Mokasyny Nessi">Mokasyny Nessi</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/nerki/damskie" title="Torebki nerki damskie">Torebki nerki damskie</a>
</li><li class="seo_row">
<a href="https://avanti24.pl/Magazyn/7,150441,27051133,modne-portfele-vans-damskie-i-meskie-modele-ktore-pokochaja.html" title="Portfele Vans">Portfele Vans</a>
</li><li class="seo_row">
<a href="https://avanti24.pl/Magazyn/7,150441,26969780,te-modne-szorty-damskie-niesamowicie-wydluzaja-nogi-przechodzisz.html" title="Szorty damskie">Szorty damskie</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/sukienki/slub-cywilny" title="Sukienki na ślub cywilny">Sukienki na ślub cywilny</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/wyprzedaz/obuwie" title="Wyprzedaż butów">Wyprzedaż butów</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/sukienki/wesele/dla-puszystych" title="Sukienki na wesele dla puszystych">Sukienki na wesele dla puszystych</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/torebki/skora" title="Skórzane torebki">Skórzane torebki</a>
</li><li class="seo_row">
<a href="https://avanti24.pl/Avanti/0,0.html" title="Avanti24.pl">Avanti24.pl</a>
</li><li class="seo_row">
<a href="https://avanti24.pl/newsy/0,0.html" title="Nowości ze świata mody i urody">Nowości ze świata mody i urody</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/sukienki/jeans" title="Sukienki jeansowe">Sukienki jeansowe</a>
</li><li class="seo_row">
<a href="https://zakupy.avanti24.pl/adidas/damskie" title="Buty Adidas damskie">Buty Adidas damskie</a>
</li>
</ul>
</li>
<li class="seo_column">
<h3>
Wiadomości
</h3>
<ul>
<li class="seo_row">
<a href="https://wiadomosci.gazeta.pl/wiadomosci/0,168571.html" title="Nowe wiadomości">Nowe wiadomości</a>
</li><li class="seo_row">
<a href="https://wiadomosci.gazeta.pl/wiadomosci/0,114884.html" title="Polityka">Polityka</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/next/0,172392.html" title="Środowisko">Środowisko</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/next/0,150859.html" title="Biznes">Biznes</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/next/0,150860.html" title="Technologie">Technologie</a>
</li><li class="seo_row">
<a href="https://next.gazeta.pl/next/0,172690.html" title="Nauka">Nauka</a>
</li><li class="seo_row">
<a href="https://kultura.gazeta.pl/kultura/7,114526,26265145,krzysztof-krawczyk-obchodzi-74-urodziny-pamietacie-wszystkie.html" title="Krzysztof Krawczyk">Krzysztof Krawczyk</a>
</li><li class="seo_row">
<a href="https://kultura.gazeta.pl/kultura/7,127222,26267890,netflix-premiery-seriali-2020-jakie-nowosci-czekaja-nas-jeszcze.html" title="Netflix premiery 2020">Netflix premiery 2020</a>
</li><li class="seo_row">
<a href="https://kultura.gazeta.pl/kultura/7,114438,26267086,mulan-chinska-legenda-powraca-na-wielki-ekran-obsada-fabula.html" title="Mulan">Mulan</a>
</li><li class="seo_row">
<a href="https://kultura.gazeta.pl/kultura/7,114438,26266731,uma-thurman-najlepsze-filmy-z-amerykanska-aktorka.html" title="Uma Turman filmy">Uma Turman filmy</a>
</li><li class="seo_row">
<a href="https://kultura.gazeta.pl/kultura/7,114438,26250633,the-new-mutants-nowy-film-z-uniwersum-x-menow-poznaj-bohaterow.html" title="The New Mutants">The New Mutants</a>
</li><li class="seo_row">
<a href="https://kultura.gazeta.pl/kultura/7,114438,26237437,the-batman-najnowsza-czesc-przygod-mrocznego-rycerza-juz-niedlugo.html" title="The Batman">The Batman</a>
</li>
</ul>
</li>
<li class="seo_column">
<h3>
Przepisy
</h3>
<ul>
<li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/0,166897.html" title="Zdrowa żywność">Zdrowa żywność</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24413779,top-3-przepisy-na-lososia-z-piekarnika.html" title="Łosoś z piekarnika">Łosoś z piekarnika</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24408969,sos-koperkowy-jak-go-zrobic-i-do-czego-podawac-sprawdzi-sie.html" title="Sos koperkowy">Sos koperkowy</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24401913,brokuly-wlasciwosci-i-pomysly-na-podanie-przepisy-na-tarte.html" title="Brokuły">Brokuły</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24402080,granola-co-to-jest-jak-przyrzadzic-domowa-granole.html" title="Granola">Granola</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24369299,frytki-belgijskie-przepis-dzieki-ktoremu-beda-idealne-sekretem.html" title="Frytki belgijskie">Frytki belgijskie</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24368758,zupa-krem-z-cukinii-przepis-nie-tylko-na-sezon.html" title="Zupa krem z cukinii">Zupa krem z cukinii</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24284273,jak-zrobic-carbonare-prosty-przepis-na-spaghetti-carbonara.html" title="Spaghetti Carbonara">Spaghetti Carbonara</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24402119,marynata-do-karkowki-z-grilla-pomysly.html" title="Marynata do karkówki">Marynata do karkówki</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24402094,marchewka-z-groszkiem-do-obiadu-jak-ja-przyrzadzic-doskonaly.html" title="Marchewka z groszkiem">Marchewka z groszkiem</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24354867,jak-zrobic-filet-z-kurczaka-jak-przyrzadzic-najpopularniejszy.html" title="Filet z kurczaka">Filet z kurczaka</a>
</li><li class="seo_row">
<a href="https://haps.pl/Haps/7,167251,24356214,jak-zrobic-tosty-francuskie-przepis-na-idealne-sniadanie-z.html" title="Tosty francuskie">Tosty francuskie</a>
</li>
</ul>
</li>
<li class="seo_column">
<h3>
Plotki
</h3>
<ul>
<li class="seo_row">
<a href="https://www.plotek.pl/plotek/7,154063,25831642,malgorzata-rozenek-urodzila-pokazala-pierwsze-zdjecie-swojego.html" title="Małgorzata Rozenek urodziła!">Małgorzata Rozenek urodziła!</a>
</li><li class="seo_row">
<a href="https://www.plotek.pl/plotek/7,154063,25761732,natalia-siwiec-odslania-cialo-fani-co-na-to-twoja-corka-modelka.html" title="Natalia Siwiec">Natalia Siwiec</a>
</li><li class="seo_row">
<a href="https://www.plotek.pl/plotek/7,154063,25762900,meghan-markle-i-ksiaze-harry-na-rozdaniu-nagrod-w-londynie.html" title="Meghan Markle i książę Harry">Meghan Markle i książę Harry</a>
</li><li class="seo_row">
<a href="https://www.plotek.pl/plotek/7,154063,25762313,katy-perry-jest-w-ciazy-mamy-najnowsze-zdjecia-piosenkarki.html" title="Katy Perry">Katy Perry</a>
</li><li class="seo_row">
<a href="https://www.plotek.pl/plotek/7,154063,25763210,agnieszka-wozniak-starak-poprowadzila-premiere-filmowa-na-scenie.html" title="Agnieszka Woźniak-Starak">Agnieszka Woźniak-Starak</a>
</li><li class="seo_row">
<a href="https://www.plotek.pl/plotek/7,154063,25762551,doda-boi-sie-koronawirusa-postanowila-nie-robic-sobie-zdjec.html" title="Doda - kroonawirus">Doda - kroonawirus</a>
</li><li class="seo_row">
<a href="https://www.plotek.pl/plotek/7,154063,25763366,paulina-krupinska-zartuje-z-siebie-na-instagramie-jak-oceniacie.html" title="Paulina Krupińska DDTVN">Paulina Krupińska DDTVN</a>
</li><li class="seo_row">
<a href="https://www.plotek.pl/plotek/7,154063,25763406,meghan-markle-i-ksiaze-harry-zakochani-do-szalenstwa-ich.html" title="Meghan Markle i książę Harry">Meghan Markle i książę Harry</a>
</li><li class="seo_row">
<a href="https://www.plotek.pl/plotek/7,154063,25763418,sylwia-lipka-skrytykowana-przez-znana-stylistke-to-jest-po.html" title="Sylwia Lipka">Sylwia Lipka</a>
</li><li class="seo_row">
<a href="https://www.plotek.pl/plotek/7,78649,25763566,anna-lewandowska-rozczulona-widokiem-klary-i-roberta-dziewczynka.html" title="Anna Lewandowska i Klara">Anna Lewandowska i Klara</a>
</li>
</ul>
</li>
<li class="seo_column">
<h3>
Fitness
</h3>
<ul>
<li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25597154,magda-gessler-w-roli-ambasadorki-body-chief-gwiazda-obiecuje.html" title="Magda Gessler">Magda Gessler</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25596215,jogurt-naturalny-kcal-i-wlasciwosci-do-czego-uzywac-jogurtu.html" title="Ile kalorii ma jogurt naturalny?">Ile kalorii ma jogurt naturalny?</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25596237,lekka-kolacja-nie-oznacza-ze-bedziesz-glodny-poznaj-3-pomysly.html" title="Lekka kolacja - 3 przepisy">Lekka kolacja - 3 przepisy</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25597431,lena-kliment-pochwalila-sie-zdjeciem-z-odlosnietym-umiesnionym.html" title="Lena Kliment">Lena Kliment</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25595031,chcesz-szybko-schudnac-znam-na-to-lepsze-i-przyjemniejsze.html" title="Jak schudnąć bez ćwiczeń?">Jak schudnąć bez ćwiczeń?</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25596282,jak-cwiczyc-miesnie-brzucha-z-pilka-gimnastyczna-przykladowy.html" title="Ćwiczenia z piłką gimnastyczną">Ćwiczenia z piłką gimnastyczną</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25598252,ile-kalorii-maja-frytki-duzo-jak-zrobic-dietetyczne-frytki.html" title="Ile kalorii mają frytki?">Ile kalorii mają frytki?</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25598186,brzuch-mozna-cwiczyc-nawet-w-plenerze-polecamy-trening-brzucha.html" title="Trening brzucha">Trening brzucha</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25596897,julia-wieniawa-w-skapym-kostiumie-kapielowym-na-instagramie.html" title="Julia Wieniawa w bikini">Julia Wieniawa w bikini</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25597083,jak-szybko-schudnac-5-trikow-ktore-mozesz-zastosowac-od-dzis.html" title="Jak szybko schudnąć?">Jak szybko schudnąć?</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25596318,sandra-kubicka-wrocila-do-treningow-po-8-miesiacach-przerwy.html" title="Sandra Kubicka">Sandra Kubicka</a>
</li><li class="seo_row">
<a href="https://myfitness.gazeta.pl/myfitness/7,166676,25597297,co-jesc-zeby-schudnac-te-piec-produktow-musisz-odstawic-jesli.html" title="Co jeść, żeby schudnąć?">Co jeść, żeby schudnąć?</a>
</li>
</ul>
</li>
</ul>
</div><!-- UZREditor --><!-- htmEOF -->
<!--24415903, [ /htm/24415/j24415903.htm ], null-->
</div>
    </div>
<!--410356607, [ /tpl/prod/modules/recommendations/recommendations.jsp ], emptyBean-->
</div>
</div>
</template>


<script>
export default {
    props: ['test']
}
</script>