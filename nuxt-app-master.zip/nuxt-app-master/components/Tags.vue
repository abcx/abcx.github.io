<template>
    <section class="tags">
    	
        <header class="tags_header">Więcej o:</header>
        <ul class="tags_list">
            <li class="tags_item" v-for="tag in data" :key="tag">
            	<a href="#" :title="tag" class="tag_link">{{tag}}</a>
            </li>
        </ul>
    </section>
</template>


<script>
export default {
    props: ['data']
}
</script>