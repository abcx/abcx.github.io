<template>
    <div class="wrapper">
        <Header/>
        <Article/>
        <Aside/>
        <Bottom/>
        <BoxSeo/>
        <Footer/>
    </div>
</template>

<style scoped>
    .wrapper {background: #f3f3ff}
</style>

<script>
    export default {
        head() {
            return {
                title: "Title",
                bodyAttrs: {
                    id: 'pageTypeId_7',
                    class: 'chrome WebKit chrome_9 LINUX simpleArt '
                }
            }
        },
    }
</script>
